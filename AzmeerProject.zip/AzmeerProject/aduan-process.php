<?php
$servername = "localhost";
$username = "syedazmeer";
$password = "123456";
$dbname = "aduan";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$complaintCategory=$_POST['complaintCategory'];
$complaintForm=$_POST['complaintForm'];
$complaintLocation=$_POST['complaintLocation'];



$sql = "INSERT INTO complaint VALUES ('$complaintCategory','$complaintForm','$complaintLocation')";
if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
 echo "<script type='text/javascript'> alert('Successfully complaint. ')</script> ";
 echo "<script type='text/javascript'>window.location='home.html'</script>";

?>