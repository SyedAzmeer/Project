-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2016 at 04:48 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aduan`
--

-- --------------------------------------------------------

--
-- Table structure for table `complaint`
--

CREATE TABLE `complaint` (
  `complaintID` int(10) NOT NULL,
  `complaintDate` date DEFAULT NULL,
  `complaintCategory` varchar(50) DEFAULT NULL,
  `complaintLocation` varchar(50) NOT NULL,
  `complaintForm` varchar(100) DEFAULT NULL,
  `studentID` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `complaint`
--

INSERT INTO `complaint` (`complaintID`, `complaintDate`, `complaintCategory`, `complaintLocation`, `complaintForm`, `studentID`) VALUES
(1000, '2016-11-02', 'GANGGUAN BEKALAN AIR DAN ELEKTRIK', 'KK2', 'GANGGUAN BEKALAN AIR DI KK TERUTAMA DI BLOK B', 'CB15007'),
(1001, '2016-11-01', 'GANGGUAN LUAR', 'KK2', 'GANGGUAN BISING TERUTAMA DI WAKTU MALAM ', 'CB15227'),
(1002, '2016-10-28', 'KEBERSIHAN', 'BLOK Y', 'KEBERSIHAN TANDAS DI BLOK Y DI TAHAP KURANG MEMUASKAN', 'CD15128'),
(1003, '2016-11-13', 'KECURIAN', 'BLOK Z', 'KEHILANGAN MOTOSIKAL DENGAN NO PENDAFTARAN ABC123', 'KA14127'),
(1004, '2016-10-07', 'GANGGUAN LUAR', 'PERPUSTAKAAN', 'GANGGUAN BUNYI KETIKA DI PERPUSTAKAAN', 'KA16193'),
(1005, '2016-11-05', 'GANGGUAN LUAR', 'KK3', 'GANGGUAN BISING TERUTAM DI WAKTU MALAM', 'PB15049'),
(1006, '2016-10-17', 'KEROSAKAN', 'KOMPLEKS SUKAN', 'KEROSAKAN PERALATAN SUKAN DI KOMPLEKS SUKAN', 'PD16012'),
(1007, '2016-11-15', 'KEBERSIHAN', 'KAFE', 'KEBERSIHAN MAKANAN DI KAFE TIDAK MEMUASKAN. SILA AMBIL TINDAKAN DENGAN KADAR SEGERA', 'SA14201'),
(1008, '2016-09-21', 'GANGGUAN BEKALAN AIR DAN ELEKTRIK', 'KK1', 'GANGGUAN BEKALAN ELEKTRIK DI BLOK C1', 'SB16068'),
(1009, '2016-11-12', 'KEROSAKAN', 'BLOK Z', 'KEROSAKAN MEJA BELAJAR DI ZDK-O6', 'TC15017'),
(1010, '0000-00-00', '', 'aduan 03', 'tandas kotor', ''),
(1011, '0000-00-00', '', 'aduan 05', 'tiada tong sampah', '');

-- --------------------------------------------------------

--
-- Table structure for table `complainttype`
--

CREATE TABLE `complainttype` (
  `complaintProblem` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `complainttype`
--

INSERT INTO `complainttype` (`complaintProblem`) VALUES
('GANGGUAN BEKALAN AIR DAN ELEKTRIK'),
('GANGGUAN LUAR'),
('KEBERSIHAN'),
('KECURIAN'),
('KEROSAKAN');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `location` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`location`) VALUES
('ASTAKA'),
('BLOK T'),
('BLOK W'),
('BLOK X'),
('BLOK Y'),
('BLOK Z'),
('CANSELERI'),
('KAFE'),
('KK1'),
('KK2'),
('KK3'),
('KK4'),
('KOMPLEKS SUKAN'),
('PERPUSTAKAAN');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staffID` varchar(10) NOT NULL,
  `staffName` varchar(50) NOT NULL,
  `staffPhoneNo` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staffID`, `staffName`, `staffPhoneNo`) VALUES
('SID14034', 'RAHMAN BIN MOKTHAR', '0127893467'),
('SID13098', 'AHMAD SHAARI BIN AZIZ', '0199865475'),
('SID15090', 'SITI AISHAH BINTI AZWAN', '0137896709'),
('SID12367', 'ROKIAH BINTI SAMAD', '0176783456'),
('SID14099', 'MUHAMMAD SYAKIR BIN AHMAD', '0113456890');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `studentID` varchar(10) NOT NULL,
  `studentName` varchar(50) NOT NULL,
  `studentFaculty` varchar(10) NOT NULL,
  `studentEmail` varchar(50) NOT NULL,
  `studentPassword` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`studentID`, `studentName`, `studentFaculty`, `studentEmail`, `studentPassword`) VALUES
('CB15141', 'SYED AZMEER ', 'FSKKP', 'Azmeervilla@gmail.com', '123456'),
('CB15227', 'AHMAD BIN MUHAMMAD', 'FSKKP', 'ahmad@gmail.com', '678'),
('CD15012', 'AHMAD AMIRUDDIN ALMUKHTAR', 'FSKKP', 'inuzukaryuta@gmail.com', 'asdf'),
('CD15128', 'AHMAD SYAHIR BIN TAQIYUDDIN', 'FSKKP', 'syahirfzp@rocketmail.com', 'syahir!@'),
('KA14127', 'AMAR AMIROO BIN ROSTAN', 'FKKSA', 'amiroo@yahoo.com', '4567amiroo'),
('KA16193', 'KHAIRUL HAIZE BIN ABDULRAHMAN', 'FKKSA', 'ag@gmail.com', '1234567890'),
('PB15049', 'SYAHIRA BT ALI', 'FIM', 'syahiraali@gmail.com', '345'),
('PD16012', 'RAJAGOBAL', 'FIM', 'rajagobal@hotmail.com', 'gobal'),
('SA14201', 'WONG MEW CHOO', 'FIST', 'mewchoo@yahoo.com', 'mewchoo!@#'),
('SB16068', 'KHAIRUNNISA BINTI KHALID', 'FIST', 'nisa@yahoo.com', 'nisa123'),
('TC15017', 'TEO LUN WEI', 'FTEK', 'lunwei@gmail.com', '678910');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `complaint`
--
ALTER TABLE `complaint`
  ADD PRIMARY KEY (`complaintID`);

--
-- Indexes for table `complainttype`
--
ALTER TABLE `complainttype`
  ADD PRIMARY KEY (`complaintProblem`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`location`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`studentID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `complaint`
--
ALTER TABLE `complaint`
  MODIFY `complaintID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1012;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
