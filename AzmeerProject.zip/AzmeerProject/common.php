<?php
   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'syedazmeer');
   define('DB_PASSWORD', '123456');
   define('DB_DATABASE', 'aduan');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>