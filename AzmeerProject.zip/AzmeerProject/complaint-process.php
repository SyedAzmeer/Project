<?php
$servername = "localhost";
$username = "syedazmeer";
$password = "123456";
$dbname = "aduan";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_POST['submit']))
{

$complaintCategory=$_POST['complaintCategory'];
$complaintLocation=$_POST['complaintLocation'];
$complaintForm=$_POST['complaintForm'];

$sql = "INSERT INTO complaint VALUES ('','','$complaintCategory','$complaintLocation','$complaintForm','')";
if ($conn->query($sql) === TRUE) {
    echo "<script type='text/javascript'> alert('Successfully ')</script> ";
 echo "<script type='text/javascript'>window.location='home.php'</script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}
$conn->close();
 

?>