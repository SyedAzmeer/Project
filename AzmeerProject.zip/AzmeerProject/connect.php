<?php
session_start();
$message="";
if(count($_POST)>0) {
$conn = mysql_connect("localhost","root","");
mysql_select_db("aduan",$conn);
$result = mysql_query("SELECT * FROM student WHERE studentID='" . $_POST["studentID"] . "' and studentPassword= '". $_POST["studentPassword"]."'");
$row  = mysql_fetch_array($result);
if(is_array($row)) {
$_SESSION["studentID"] = $row[studentID];
$_SESSION["studentPassword"] = $row[studentPassword];
$_SESSION["studentName"] = $row[studentName];
$_SESSION["studentFaculty"] = $row[studentFaculty];
$_SESSION["studentEmail"] = $row[studentEmail];
} else {
$message = "Invalid Username or Password!";
 echo "<script type='text/javascript'> alert('Incorrect Username or Password. Please Try Again')</script> ";
					echo "<script type='text/javascript'>location.href='login.html'</script>";
}
}
if(isset($_SESSION["studentID"])) {
header("Location:home.php");
}
?>

	
