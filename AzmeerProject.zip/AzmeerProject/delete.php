<?php
$servername = "localhost";
$username = "syedazmeer";
$password = "123456";
$dbname = "aduan";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

if(isset($_GET['studentID']))
{
$studentID=$_GET['studentID'];

// sql to delete a record
$sql = "DELETE FROM student WHERE studentID = '$studentID'";

if ($conn->query($sql) === TRUE) {
    echo "<script type='text/javascript'> alert('Successfully deleted. ')</script> ";
 echo "<script type='text/javascript'>window.location='view.php'</script>";
} else {
    echo "Error deleting record: " . $conn->error;
}
}

$conn->close();
?>