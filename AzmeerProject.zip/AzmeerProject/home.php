
<html>
<body>

<head>
<?php
session_start();

if(!$_SESSION['studentID']){
	
	header("location: login.html");
}
?>

<link rel="stylesheet" type="text/css" href="navigationstyle.css">


</head>



<div id="header">  <img src='http://www.ump.edu.my/download/logo-rasmi-ump.png' align='middle' width='20%' height='15%'><img src='https://terengganutimes.com/wp-content/uploads/2014/10/ADUAN_01.png' align='right' width='20%' height='15%'><br/><br/></div>

<body>

<ul class="topnav" id="myTopnav">

<?php
if($_SESSION["studentID"]) {
?>
<li><a class="active" >Welcome <?php echo $_SESSION["studentName"]; ?> to E-aduan</a><br></li>
<?php
}
?>
   <li><a href="http://localhost/xampp/project/home.php">Homepage</a></li>
  <li><a href="http://localhost/xampp/project/status.php">View Status</a></li>
  <li><a href="http://localhost/xampp/project/view.php">Update List</a></li>
  <li><a href="http://localhost/xampp/project/FAQ.html">FAQ</a></li>
  <li><a href="logout-process.php">LOG OUT</a></li>
  
  <li class="icon">
    <a href="javascript:void(0);" style="font-size:15px;" onclick="myFunction()">☰</a>
  </li>
</ul>

<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>

<style>
.tableheader {
background-color: #2F4F4F;
color:white;
font-weight:bold;
}
.tablerow {
background-color: ##F8F8FF;
color:DarkSlateGray;
}
.message {
color: 	#2F4F4F;
font-weight: bold;
text-align: center;
width: 100%;
}
</style>
<title>Maximum Zoom imagery service</title>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
	
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
    </style>
	<br>
	<br>
	
</body>



<input type="hidden" name="language" id="language" value="2" />
<table align="center" id="table" ><br><br>
<input type="hidden" name="language" id="language" value="2" />
<table border="0" cellpadding="10" cellspacing="0" width="900" align="center">
<tr class="tableheader">
<td align="center" colspan="2">E-ADUAN</td>
</tr>
<tr class="tablerow">
<td class="td" colspan="2"><br/>Panduan :<br> Perlu diisi <span class="span">*</span><br>Isi salah satu  <span class="span2">**</span> <br/></td></tr>
<tr class="tableheader">
<td align="center" colspan="2">STUDENT INFORMATION</td>
</tr>
<tr class="tablerow">
<td>
<?php
if($_SESSION["studentID"]) {
?>

Student ID&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp   : <?php echo $_SESSION["studentID"]; ?><br>
Student Name&nbsp&nbsp&nbsp&nbsp :<?php echo $_SESSION["studentName"]; ?><br>
Faculty&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp:<?php echo $_SESSION['studentFaculty']; ?><br>
Email&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp :<?php echo $_SESSION['studentEmail']; ?><br>

<?php
}
?>
</td>
</tr>
<tr class="tableheader">
<td align="center" colspan="2">MAPS</td>
</tr>
</table>

<input type="hidden" name="language" id="language" value="2" />
<table border="0" cellpadding="10" cellspacing="0" width="900" align="center"><br><br><br>

 <center><div id="map" style="width:800px;height:400px">

    <script>
	
      var map;
      var maxZoomService;
      var infoWindow;

      function initMap() {
        map = new google.maps.Map(document.getElementById('map'), {
          zoom: 40,
          center: {lat: 3.722510, lng: 103.121126},
          mapTypeId: 'hybrid'
        });

        infoWindow = new google.maps.InfoWindow();

        maxZoomService = new google.maps.MaxZoomService();

        map.addListener('click', showMaxZoom);
      }

      function showMaxZoom(e) {
        maxZoomService.getMaxZoomAtLatLng(e.latLng, function(response) {
          if (response.status !== 'OK') {
            infoWindow.setContent('Error in MaxZoomService');
          } else {
            infoWindow.setContent(
                'The maximum zoom at this location is: ' + response.zoom);
          }
          infoWindow.setPosition(e.latLng);
          infoWindow.open(map);
        });
      }
    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVBkzMTrkCmNe5k8zL3afAMk-tmxezIOQ&callback=initMap">
    </script></center><br><br>
</table>

<form name="borang" action="complaint-process.php" method="post"  onsubmit="return checkField()"  enctype="multipart/form-data"><br><br>
<input type="hidden" name="language" id="language" value="2" />
<table border="0" cellpadding="10" cellspacing="0" width="900" align="center">
<tr class="tableheader">
<td align="center" colspan="2">COMPLAINT FORM</td>
</tr>
<tr class="tablerow">
<td align="left" class="td" name='complaintTime' id='complaintTime'>Current Time</td>
<td><?php
        echo "". date('Y/m/d')."<br>";
   ?>
</td>
</tr>
<tr class="tablerow">
<td align="left" class="td" name='complaintDate' id='complaintDate'>Current Date</td>
<td><?php
   date_default_timezone_set("Asia/Kuala_Lumpur");
  echo "". date('h:i:sa')."<br>";
   ?>
</td>
</tr>
<tr class="tablerow">
<td align="left" class="td">Category</td>
<td><select name='complaintCategory id='complaintCategory' onchange="return getCAT()" required>
<option value="0">[Sila Pilih]</option>
<option value='aduan 01'>Gangguan Bekalan Air dan Elektrik    </option>
<option value='aduan 02'>Kebersihan</option>
<option value='aduan 03'>Gangguan Luar  e.g Bising</option>
<option value='aduan 04'>Kerosakan</option>
<option value='aduan 05'>Kecurian</option> </select>


<tr class="tablerow">
<td align="left" class="td">Location</td>
<td><select name='complaintLocation' id='complaintLocation' onchange="return getCAT()" required>

<option value="0">[Sila Pilih]</option>
<option value='aduan 01'>KK1</option>
<option value='aduan 02'>KK2</option>
<option value='aduan 03'>KK3</option>
<option value='aduan 04'>KK4</option>
<option value='aduan 05'>BLOK T</option>    
<option value='aduan 03'>BLOK W</option>
<option value='aduan 03'>BLOK X</option>
<option value='aduan 04'>BLOK Y</option>
<option value='aduan 05'>BLOK Z</option>        
<option value='aduan 05'>PERPUSTAKAAN</option>    
<option value='aduan 03'>CANSELERI</option>
<option value='aduan 03'>KOMPLEKS SUKAN</option>
<option value='aduan 04'>ASTAKA</option>
<option value='aduan 05'>KAFE</option>                         
</select>
<span class="span">*</span>
</td>
</tr>

<tr class="tablerow">
<td align="left" class="td">Complaint</td>
<td><textarea name='complaintForm' id='complaintForm' onKeyPress="return taLimit()" onKeyUp="return taCount(myCounter)"  name="remark" cols="50" rows="5" id="remark" maxLength="200" required></textarea> 
</tr>


<tr class="tablerow">
<td align="left" class="td">Upload Image</td>
<td><form action="upload.php" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
    <input type="submit" value="Upload Image" name="submit">
</form></td></tr>

<tr class="tablerow">
<td align="center" colspan="2"><br/><button type="submit" value="submit" name="submit"/>Send</button> <button type="reset" value="reset"/>Reset</button> <br/></td>
</tr>
</table>
<br><br>
</form>
</div>

<div id="footer">
<center><br><br><br>Hakcipta © 2016 Universiti Malaysia Pahang. Hak cipta terpelihara.</center>


</div>
</body>
</html>
