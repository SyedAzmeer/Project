<?php
   include("common.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $studentID = mysqli_real_escape_string($db,$_POST['studentID']);
      $studentPassword = mysqli_real_escape_string($db,$_POST['studentPassword']); 
      
      $sql = "SELECT * FROM student WHERE studentID = '$studentID' and studentPassword = '$studentPassword'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {

         $_SESSION['login_user'] = $studentID;
         
         echo "<script type='text/javascript'> alert('Welcome. Your Login sucessful ')</script> ";
					echo "<script type='text/javascript'>window.location='home.php'</script>";
      }else {
         $error = "Your Login Name or Password is invalid";
		 echo "<script type='text/javascript'> alert('Incorrect Username or Password. Please Try Again')</script> ";
					echo "<script type='text/javascript'>location.href='login.html'</script>";
      }
   }