<?php
$servername = "localhost";
$username = "syedazmeer";
$password = "123456";
$dbname = "aduan";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$studentID=$_POST['studentID'];
$studentName=$_POST['studentName'];
$studentFaculty=$_POST['studentFaculty'];
$studentEmail=$_POST['studentEmail'];
$studentPassword=$_POST['studentPassword'];


$sql = "INSERT INTO student VALUES ('$studentID','$studentName','$studentFaculty','$studentEmail','$studentPassword')";
if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
 echo "<script type='text/javascript'> alert('Successfully registered. ')</script> ";
 echo "<script type='text/javascript'>window.location='login.html'</script>";

?>