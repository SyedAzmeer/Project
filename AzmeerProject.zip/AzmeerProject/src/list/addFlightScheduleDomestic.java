
package list;

public class addFlightScheduleDomestic {
        private String From, To, Date, Time, Airliner,TotalSeat,Price;
        
        public addFlightScheduleDomestic(String from){
            this.From = "unknown";
        }
        
        public addFlightScheduleDomestic(String from, String to){
            this.From = "unknown";
            this.To = "unknown";
        }
        
        public addFlightScheduleDomestic(String from, String to,String date){
            this.From = "unknown";
            this.To = "unknown";
            this.Date = "unknown";
        }
        
        public addFlightScheduleDomestic(String from, String to,String date, String Time){
            this.From = "unknown";
            this.To = "unknown";
            this.Date = "unknown";
            this.Time = "unknown";
        }
        
        public addFlightScheduleDomestic(String from, String to,String date, String Time, String Airliner){
            this.From = "unknown";
            this.To = "unknown";
            this.Date = "unknown";
            this.Time = "unknown";
            this.Airliner = "Airliner";
        }
        
        public addFlightScheduleDomestic(String from, String to,String date, String Time, String Airliner, String TotalSeat){
            this.From = "unknown";
            this.To = "unknown";
            this.Date = "unknown";
            this.Time = "unknown";
            this.Airliner = "unknown";
            this.TotalSeat = "unknown";
        }
        
        public addFlightScheduleDomestic(String from, String to, String date, String time, String airliner, String totalSeat, String price){
            this.From = from;
            this.To = to;
            this.Date = date;
            this.Time = time;
            this.Airliner = airliner;
            this.TotalSeat = totalSeat;
            this.Price = price;
        }
        
        public void setFrom(String from){
            this.From = from;
        }
        
        public String getFrom(){
            return this.From;
        }
        
        public void setTo(String to){
            this.To = to;
        }
        
        public String getTo(){
            return this.To;
        }
        
        public void setDate(String date){
            this.Date = date;
        }
        
        public String getDate(){
            return this.Date;
        }
        
        public void setTime(String time){
            this.Time = time;
        }
        
        public String getTime(){
            return this.Time;
        }
        
        public void setAirliner(String airliner ){
            this.Airliner = airliner;
        }
        
        public String getAirliner(){
            return this.Airliner;
        }
        
        public void setTotalSeat(String totalSeat){
            this.TotalSeat = totalSeat;
        }
        
        public String getTotalSeat(){
            return this.TotalSeat;
        }
        
        public void setPrice(String price){
            this.Price = price;
        }
        
        public String getPrice(){
            return this.Price;
        }  
}
