package project;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;


public class AddFlightSchedule extends javax.swing.JFrame {
    int choice;
    String From, To, Date, Time, Airliner,TotalSeat,Price;
    
    public AddFlightSchedule() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        AirlinerTextField = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        TotalSeatTextField = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        PriceTextField = new javax.swing.JTextField();
        SubmitButton = new javax.swing.JButton();
        BackButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        InternationalRadioButton = new javax.swing.JRadioButton();
        DomesticRadioButton = new javax.swing.JRadioButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        DepartTimeField = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        FromComboBox = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        ToComboBox = new javax.swing.JComboBox<>();
        DepartureDateField = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(417, 466));
        setMinimumSize(new java.awt.Dimension(417, 466));

        jLabel6.setText("Total Seat");

        jLabel7.setText("Price/Seat");

        SubmitButton.setBackground(new java.awt.Color(255, 255, 255));
        SubmitButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/submit.png"))); // NOI18N
        SubmitButton.setText("Submit");
        SubmitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubmitButtonActionPerformed(evt);
            }
        });

        BackButton.setBackground(new java.awt.Color(255, 255, 255));
        BackButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/back.png"))); // NOI18N
        BackButton.setText("Back");
        BackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackButtonActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("Add Flight Schedule");

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        InternationalRadioButton.setText("International");
        InternationalRadioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InternationalRadioButtonActionPerformed(evt);
            }
        });

        DomesticRadioButton.setText("Domestic");
        DomesticRadioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DomesticRadioButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(InternationalRadioButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 86, Short.MAX_VALUE)
                .addComponent(DomesticRadioButton)
                .addGap(50, 50, 50))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(InternationalRadioButton)
                    .addComponent(DomesticRadioButton))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel2.setText("Departure Date");

        jLabel3.setText("Departure Time");

        jLabel4.setText("Airliner");

        jLabel8.setText("Departure From");

        FromComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "KLIA ", "KLIA 2" }));

        jLabel9.setText("Departure To");

        ToComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "South Korea", "Jakarta", "Thailand", "Singapore" }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(TotalSeatTextField)
                                    .addComponent(PriceTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
                                    .addComponent(AirlinerTextField)
                                    .addComponent(DepartTimeField, javax.swing.GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
                                    .addComponent(DepartureDateField)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel9))
                                .addGap(27, 27, 27)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(FromComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(ToComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(51, 51, 51)
                                .addComponent(BackButton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(SubmitButton))))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jLabel1)))
                .addContainerGap(59, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(FromComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(ToComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(DepartureDateField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(DepartTimeField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(AirlinerTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(TotalSeatTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(PriceTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(BackButton, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SubmitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SubmitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubmitButtonActionPerformed
        BufferedWriter writer;
        switch(choice){
            case 1 : 
                try
                {
                    From = (String)FromComboBox.getSelectedItem();
                    To = (String)ToComboBox.getSelectedItem();
                    Date = DepartureDateField.getText();
                    Time = DepartTimeField.getText();
                    Airliner = AirlinerTextField.getText();
                    TotalSeat = TotalSeatTextField.getText();
                    Price = PriceTextField.getText();
                    
                    
                    File file = new File("addFlightScheduleInternational.txt");
                    writer = new BufferedWriter(new FileWriter("addFlightScheduleInternational.txt",true));
                    writer.write(From + "\t" + To + "\t" + Date + "\t" + Time + "\t" + Airliner + "\t" + TotalSeat + "\t" + Price);
                    writer.newLine();
                    writer.close();
                }
                catch(FileNotFoundException ex){} 
                catch(IOException ex){}
                
                    FromComboBox.setSelectedItem("");
                    ToComboBox.setSelectedItem("");
                    DepartureDateField.setText("");
                    DepartTimeField.setText("");
                    AirlinerTextField.setText("");
                    TotalSeatTextField.setText("");
                    PriceTextField.setText("");
                    InternationalRadioButton.setSelected(false);
                    DomesticRadioButton.setSelected(false);
                        
                        if(JOptionPane.YES_OPTION != JOptionPane.showConfirmDialog(null, "Successful added!\nReturn to menu?","",JOptionPane.YES_NO_OPTION))
                        {
                        }else
                        {
                            AdminMenu admin = new AdminMenu();
                            admin.setVisible(true);
                            this.dispose();
                        }
                    break;
            case 2 : 
                 
                try
                {
                    From = (String)FromComboBox.getSelectedItem();
                    To = (String)ToComboBox.getSelectedItem();
                    Date = DepartureDateField.getText();
                    Time = DepartTimeField.getText();
                    Airliner = AirlinerTextField.getText();
                    TotalSeat = TotalSeatTextField.getText();
                    Price = PriceTextField.getText();
                    
                    File file = new File("addFlightScheduleDomestic.txt");
                    writer = new BufferedWriter(new FileWriter("addFlightScheduleDomestic.txt",true));
                    writer.write(FromComboBox.getSelectedItem() + "\t" + ToComboBox.getSelectedItem() + "\t" + DepartureDateField.getText() + "\t" + DepartTimeField.getText() + "\t" + AirlinerTextField.getText() + "\t" + TotalSeatTextField.getText() + "\t" + PriceTextField.getText());
                    writer.newLine();
                    writer.close();
                }
                catch(FileNotFoundException ex){} 
                catch(IOException ex){}
                    FromComboBox.setSelectedItem("");
                    ToComboBox.setSelectedItem("");
                    DepartureDateField.setText("");
                    DepartTimeField.setText("");
                    AirlinerTextField.setText("");
                    TotalSeatTextField.setText("");
                    PriceTextField.setText("");
                    InternationalRadioButton.setSelected(false);
                    DomesticRadioButton.setSelected(false);
                        
                        if(JOptionPane.YES_OPTION != JOptionPane.showConfirmDialog(null, "Successful added!\nReturn to menu?","",JOptionPane.YES_NO_OPTION))
                        {
                        }else
                        {
                            AdminMenu admin = new AdminMenu();
                            admin.setVisible(true);
                            this.dispose();
                        }
                    break;
            default: JOptionPane.showInputDialog(null, "Please Select Which Schedule to Update");
        }
    }//GEN-LAST:event_SubmitButtonActionPerformed

    private void BackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackButtonActionPerformed
        AdminMenu admin = new AdminMenu();
        this.dispose();
        admin.setVisible(true);
    }//GEN-LAST:event_BackButtonActionPerformed

    private void InternationalRadioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InternationalRadioButtonActionPerformed
        if(InternationalRadioButton.isSelected())
        {
            DomesticRadioButton.setSelected(false);
            choice = 1;
        }
        else
        {
            InternationalRadioButton.setSelected(false);
            DomesticRadioButton.setSelected(false);
        }
    }//GEN-LAST:event_InternationalRadioButtonActionPerformed

    private void DomesticRadioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DomesticRadioButtonActionPerformed
        if(DomesticRadioButton.isSelected())
        {
            InternationalRadioButton.setSelected(false);
            choice = 2;
        }
        else
        {
            InternationalRadioButton.setSelected(false);
            DomesticRadioButton.setSelected(false);
        }
    }//GEN-LAST:event_DomesticRadioButtonActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AddFlightSchedule.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AddFlightSchedule.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AddFlightSchedule.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AddFlightSchedule.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddFlightSchedule().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField AirlinerTextField;
    private javax.swing.JButton BackButton;
    private javax.swing.JTextField DepartTimeField;
    private javax.swing.JTextField DepartureDateField;
    private javax.swing.JRadioButton DomesticRadioButton;
    private javax.swing.JComboBox<String> FromComboBox;
    private javax.swing.JRadioButton InternationalRadioButton;
    private javax.swing.JTextField PriceTextField;
    private javax.swing.JButton SubmitButton;
    private javax.swing.JComboBox<String> ToComboBox;
    private javax.swing.JTextField TotalSeatTextField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
