
package project;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

public class ListFlightSchedule extends javax.swing.JFrame {
    
    String From, To, Date, Time, Airliner,TotalSeat,Price;
    
    public ListFlightSchedule() {
        initComponents();
        
         try {
            DefaultTableModel international = (DefaultTableModel) TableInternational.getModel();
            final FileInputStream is;
            File f = new File("addFlightScheduleInternational.txt");
            is = new FileInputStream(f);
            InsertData(is);

            Scanner scan = new Scanner(is);
            String[] array;
            while (scan.hasNextLine()) {
                String line = scan.nextLine();
                if(line.indexOf(",")>-1)
                array = line.split(",");
                else
                array = line.split("\t");
                Object[] data = new Object[array.length];
                System.arraycopy(array, 0, data, 0, array.length);
                international.addRow(data);
            }
            TableInternational.setModel(international);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ListFlightSchedule.class.getName()).log(Level.SEVERE, null, ex);
        }
        ///////////////////////
         try {
            DefaultTableModel domestic = (DefaultTableModel) TableDomestic.getModel();
            final FileInputStream is;
            File f = new File("addFlightScheduleDomestic.txt");
            is = new FileInputStream(f);
            InsertData2(is);

            Scanner scan = new Scanner(is);
            String[] array;
            while (scan.hasNextLine()) {
                String line = scan.nextLine();
                if(line.indexOf(",")>-1)
                array = line.split(",");
                else
                array = line.split("\t");
                Object[] data = new Object[array.length];
                System.arraycopy(array, 0, data, 0, array.length);
                domestic.addRow(data);
            }
            TableDomestic.setModel(domestic);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ListFlightSchedule.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void InsertData(FileInputStream is){
        DefaultTableModel international = (DefaultTableModel) TableInternational.getModel();
        
        Scanner scan = new Scanner(is);
        String[] array;
        while(scan.hasNextLine()){
            String line = scan.nextLine();
                if(line.indexOf(",")>-1)
                {
                    array = line.split(",");
                }
                else
                {
                    array = line.split("\t");
                }
            Object[] data = new Object[array.length];
            System.arraycopy(array, 0, data, 0, array.length);
            international.addRow(data);
        }
        TableInternational.setModel(international);
    }
    
    public void InsertData2(FileInputStream is){
        DefaultTableModel domestic = (DefaultTableModel) TableDomestic.getModel();
        
        Scanner scan = new Scanner(is);
        String[] array;
        while(scan.hasNextLine()){
            String line = scan.nextLine();
                if(line.indexOf(",")>-1)
                {
                    array = line.split(",");
                }
                else
                {
                    array = line.split("\t");
                }
            Object[] data = new Object[array.length];
            System.arraycopy(array, 0, data, 0, array.length);
            domestic.addRow(data);
        }
        TableDomestic.setModel(domestic);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        TableInternational = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        TableDomestic = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        lMessage = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        TableInternational.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "From", "To", "Date", "Time", "Airliner", "Total Seat", "Price/Seat"
            }
        ));
        jScrollPane1.setViewportView(TableInternational);

        jLabel1.setText("International");

        jLabel2.setText("Domestic");

        TableDomestic.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "From", "To", "Date", "Time", "Airliner", "Total Seat", "Price/Seat"
            }
        ));
        jScrollPane2.setViewportView(TableDomestic);

        jButton3.setBackground(new java.awt.Color(255, 255, 255));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/back.png"))); // NOI18N
        jButton3.setText("Back");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(255, 255, 255));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/delete.png"))); // NOI18N
        jButton2.setText("Delete");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(151, 151, 151)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(199, 199, 199))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lMessage)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton2)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 479, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 474, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lMessage)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        DefaultTableModel international = (DefaultTableModel)TableInternational.getModel();
        DefaultTableModel domestic = (DefaultTableModel) TableDomestic.getModel();
        
        if(TableInternational.getSelectedRow() == -1 ){
        }else{
            international.removeRow(TableInternational.getSelectedRow());
        }
        
        if(TableDomestic.getSelectedRow() == -1){
        }else{
            domestic.removeRow(TableDomestic.getSelectedRow());
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
            try {
                    BufferedWriter bw = new BufferedWriter (new FileWriter("addFlightScheduleInternational.txt"));
                    bw.write("");
                    bw.close();
                } catch (IOException ex) {
                    Logger.getLogger(ListFlightSchedule.class.getName()).log(Level.SEVERE, null, ex);
                }
                try {
                    BufferedWriter bw = new BufferedWriter (new FileWriter("addFlightScheduleInternational.txt"));
                    for(int i=0;i<TableInternational.getRowCount(); i++){
                        for(int j=0;j<TableInternational.getColumnCount(); j++){
                            bw.write((String)TableInternational.getModel().getValueAt(i,j)+"\t");
                        }
                        bw.newLine(); 
                    }
                    bw.close();
                } catch (IOException ex) {
                    Logger.getLogger(ListFlightSchedule.class.getName()).log(Level.SEVERE, null, ex);
                }
        try {
                    BufferedWriter bw = new BufferedWriter (new FileWriter("addFlightScheduleDomestic.txt"));
                    bw.write("");
                    bw.close();
                } catch (IOException ex) {
                    Logger.getLogger(ListFlightSchedule.class.getName()).log(Level.SEVERE, null, ex);
                }
                try {
                    BufferedWriter bw = new BufferedWriter (new FileWriter("addFlightScheduleDomestic.txt"));
                    for(int i=0;i<TableDomestic.getRowCount(); i++){
                        for(int j=0;j<TableDomestic.getColumnCount(); j++){
                            bw.write((String)TableDomestic.getModel().getValueAt(i,j)+"\t");
                        }
                        bw.newLine(); 
                    }
                    bw.close();
                } catch (IOException ex) {
                    Logger.getLogger(ListFlightSchedule.class.getName()).log(Level.SEVERE, null, ex);
                }
                    AdminMenu admin = new AdminMenu();
                    admin.setVisible(true);
                    this.dispose();
            
    }//GEN-LAST:event_jButton3ActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ListFlightSchedule.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ListFlightSchedule.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ListFlightSchedule.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ListFlightSchedule.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ListFlightSchedule().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TableDomestic;
    private javax.swing.JTable TableInternational;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lMessage;
    // End of variables declaration//GEN-END:variables
}
