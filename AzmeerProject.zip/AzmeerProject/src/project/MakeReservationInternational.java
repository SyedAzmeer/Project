
package project;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class MakeReservationInternational extends javax.swing.JFrame {

    String From, To, Date, Time, Airliner,TotalSeat,Price;
    
    public MakeReservationInternational() {
        initComponents();
        
         try {
            DefaultTableModel international = (DefaultTableModel) TableInternational.getModel();
            final FileInputStream is;
            File f = new File("addFlightScheduleInternational.txt");
            is = new FileInputStream(f);
            InsertData2(is);

            Scanner scan = new Scanner(is);
            String[] array;
            while(scan.hasNextLine())
            {
                String line = scan.nextLine();
                if(line.indexOf(",") > -1)
                {
                    array = line.split(",");
                }else
                {
                    array = line.split("\t");
                    Object[] data = new Object[array.length];
                    System.arraycopy(array, 0, data, 0, array.length);
                    international.addRow(data);
                }
            }
            TableInternational.setModel(international);
        }catch(FileNotFoundException ex)
        {
            Logger.getLogger(ListFlightSchedule.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void filter(String query){
        DefaultTableModel international = (DefaultTableModel)TableInternational.getModel();
        TableRowSorter<DefaultTableModel> tr = new TableRowSorter<DefaultTableModel>(international);
        TableInternational.setRowSorter(tr);
        
        if(query != "none"){
            tr.setRowFilter(RowFilter.regexFilter(query));
        }else{
            TableInternational.setRowSorter(tr);
        }
        
    }
    
    public void InsertData2(FileInputStream is){
        DefaultTableModel international = (DefaultTableModel)TableInternational.getModel();
        
        Scanner scan = new Scanner(is);
        String[] array;
        while(scan.hasNextLine()){
            String line = scan.nextLine();
                if(line.indexOf(",")>-1)
                {
                    array = line.split(",");
                }
                else
                {
                    array = line.split("\t");
                }
            Object[] data = new Object[array.length];
            System.arraycopy(array, 0, data, 0, array.length);
            international.addRow(data);
        }
        TableInternational.setModel(international);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        ToComboBox = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        TableInternational = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("Search");

        jButton2.setBackground(new java.awt.Color(255, 255, 255));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/back.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        ToComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "South Korea", "Jakarta", "Thailand", "Singapore" }));
        ToComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                ToComboBoxItemStateChanged(evt);
            }
        });
        ToComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ToComboBoxActionPerformed(evt);
            }
        });

        jLabel1.setText("From:");

        jTextField2.setEditable(false);
        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });

        TableInternational.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "From", "To", "Date", "Time", "Airliner", "Total Seat", "Price/Seat"
            }
        ));
        TableInternational.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TableInternationalMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(TableInternational);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 532, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel1)
                                    .addGap(18, 18, 18)
                                    .addComponent(ToComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 512, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(0, 0, Short.MAX_VALUE))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(24, 24, 24)
                            .addComponent(jLabel3)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addContainerGap()))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 447, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jButton2)
                        .addComponent(jLabel3))
                    .addGap(58, 58, 58)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(ToComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(40, 40, 40)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        MenuMakeReservation menu = new MenuMakeReservation();
        this.dispose();
        menu.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void ToComboBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_ToComboBoxItemStateChanged
        String query = ToComboBox.getSelectedItem().toString();
        filter(query);
    }//GEN-LAST:event_ToComboBoxItemStateChanged

    private void ToComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ToComboBoxActionPerformed
        switch(ToComboBox.getSelectedIndex()){

            case 0:
            To = "South Korea";
            jTextField2.setText(To); break;
            case 1:
            To = "Jakarta";
            jTextField2.setText(To); break;
            case 2:
            To = "Thailand";
            jTextField2.setText(To); break;
            case 3:
            To = "Singapore";
            jTextField2.setText(To); break;
        }
    }//GEN-LAST:event_ToComboBoxActionPerformed

    private void TableInternationalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TableInternationalMouseClicked
        int num = TableInternational.getSelectedRow();
        TableModel international = TableInternational.getModel();

        From = international.getValueAt(num,0).toString();
        To = international.getValueAt(num,1).toString();
        Date = international.getValueAt(num,2).toString();
        Time = international.getValueAt(num,3).toString();
        Airliner = international.getValueAt(num,4).toString();
        TotalSeat = international.getValueAt(num,5).toString();
        Price = international.getValueAt(num,6).toString();

        MakeReservationInternational1 make = new MakeReservationInternational1();
        make.FlightDetails(From, To, Date,Time,Airliner,TotalSeat,Price);
        make.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_TableInternationalMouseClicked

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        
    }//GEN-LAST:event_jTextField2ActionPerformed

    public static void main(String args[]) {
       
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MakeReservationInternational.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MakeReservationInternational.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MakeReservationInternational.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MakeReservationInternational.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MakeReservationInternational().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TableInternational;
    private javax.swing.JComboBox<String> ToComboBox;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField2;
    // End of variables declaration//GEN-END:variables
}
