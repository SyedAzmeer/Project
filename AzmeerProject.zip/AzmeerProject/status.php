<!DOCTYPE>
<html>
<head>
<?php
session_start();

if(!$_SESSION['studentID']){
	
	header("location: login.html");
}
?>

<link rel="stylesheet" type="text/css" href="navigationstyle.css">
<div id="header">  <img src='http://www.ump.edu.my/download/logo-rasmi-ump.png' align='middle' width='20%' height='15%'><img src='https://terengganutimes.com/wp-content/uploads/2014/10/ADUAN_01.png' align='right' width='20%' height='15%'><br/><br/></div>


<body>
<ul class="topnav" id="myTopnav">
<?php
if($_SESSION["studentID"]) {
?>
<li><a class="active" >Welcome <?php echo $_SESSION["studentName"]; ?> to E-aduan</a><br></li>
<?php
}
?>
   <li><a href="http://localhost/xampp/project/home.php">Homepage</a></li>
  <li><a href="http://localhost/xampp/project/status.php">View Status</a></li>
  <li><a href="http://localhost/xampp/project/view.php">Update List</a></li>
  <li><a href="http://localhost/xampp/project/FAQ.html">FAQ</a></li>
  <li><a href="logout-process.php">LOG OUT</a></li>
  <li class="icon">
    <a href="javascript:void(0);" style="font-size:15px;" onclick="myFunction()">☰</a>
  </li>
</ul>
<style>
.tableheader {
background-color: #2F4F4F;
color:white;
font-weight:bold;
}
.tablerow {
background-color: ##F8F8FF;
color:DarkSlateGray;
}
.message {
color: 	#2F4F4F;
font-weight: bold;
text-align: center;
width: 100%;
}
</style>
<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
<div><p align='right'><a href='main.php?lang=1'><font size='1px' face='Georgia, Arial, Garamond'><b>ENGLISH</b></font></a></p><br>

</div>

 <style>
.tableheader {
background-color: #2F4F4F;
color:white;
font-weight:bold;
}
.tablerow {
background-color: ##F8F8FF;
color:DarkSlateGray;
}
.message {
color: 	#2F4F4F;
font-weight: bold;
text-align: center;
width: 100%;
}
</style>
</body>
<form name="borang" action="register.php?" method="post"  onsubmit="return checkField()"  enctype="multipart/form-data">
<input type="hidden" name="language" id="language" value="2" />
<table border="0" cellpadding="10" cellspacing="0" width="900" align="center">
<tr class="tableheader">
<td align="center" colspan="2">STUDENT INFORMATION</td>
</tr>
<tr class="tablerow">
<td>
<?php
if($_SESSION["studentID"]) {
?>

Student ID&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp   : <?php echo $_SESSION["studentID"]; ?><br>
Student Name&nbsp&nbsp&nbsp&nbsp :<?php echo $_SESSION["studentName"]; ?><br>
Faculty&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp:<?php echo $_SESSION['studentFaculty']; ?><br>
Email&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp :<?php echo $_SESSION['studentEmail']; ?><br>

<?php
}
?>
</td>
</tr>
<tr class="tableheader">
<td align="center" colspan="2">STATUS INFORMATION</td>
</tr>
<tr class="tablerow">
<td align="left" class="td">Current Date</td>
<td><?php
        echo "". date('Y/m/d')."<br>";
   ?>
</td>
</tr>
<tr class="tablerow">
<td align="left" class="td">Current Time</td>
<td><?php
   date_default_timezone_set("Asia/Kuala_Lumpur");
  echo "". date('h:i:sa')."<br>";
   ?>
</td>
</tr>
<form name="borang" action="connect.php?" method="post"  onsubmit="return checkField()"  enctype="multipart/form-data">

</tr>
</form>
<tr class="tablerow">
<td align="left" class="td">Date Occured</td>
<td><input type="text" name="DateOccured: " id="DateOccured: " required></td>
</tr>
<tr class="tablerow">
<td align="left" class="td">Description</td>
<td><textarea onKeyPress="return taLimit()" onKeyUp="return taCount(myCounter)"  name="remark" cols="50" rows="5" id="remark" maxLength="200"></textarea> 
</tr>
<tr class="tablerow">
<td align="left" class="td">Remark</td>
<td><textarea onKeyPress="return taLimit()" onKeyUp="return taCount(myCounter)"  name="remark" cols="50" rows="5" id="remark" maxLength="200">
</textarea> 
</tr>

</table>



<br><br>
</form>
</div>
<div id="footer">

</div>
</body>
</html>