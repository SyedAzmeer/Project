

<html>


<head>
<?php
session_start();

if(!$_SESSION['studentID']){
	
	header("location: login.html");
}
?>


<link rel="stylesheet" type="text/css" href="navigationstyle.css">


</head>



<div id="header">  <img src='http://www.ump.edu.my/download/logo-rasmi-ump.png' align='middle' width='20%' height='15%'><img src='https://terengganutimes.com/wp-content/uploads/2014/10/ADUAN_01.png' align='right' width='20%' height='15%'><br/><br/></div>

<body>

<ul class="topnav" id="myTopnav">

<?php
if($_SESSION["studentID"]) {
?>
<li><a class="active" >Welcome <?php echo $_SESSION["studentName"]; ?> to E-aduan</a><br></li>
<?php
}
?>
   <li><a href="http://localhost/xampp/project/home.php">Homepage</a></li>
  <li><a href="http://localhost/xampp/project/status.php">View Status</a></li>
  <li><a href="http://localhost/xampp/project/view.php">Update List</a></li>
  <li><a href="http://localhost/xampp/project/FAQ.html">FAQ</a></li>
  <li><a href="logout-process.php">LOG OUT</a></li>
  
  <li class="icon">
    <a href="javascript:void(0);" style="font-size:15px;" onclick="myFunction()">☰</a>
  </li>
</ul>

<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>

</body>

<style>
.tableheader {
background-color: #2F4F4F;
color:white;
font-weight:bold;
}
.tablerow {
background-color: ##F8F8FF;
color:DarkSlateGray;
}
.message {
color: 	#2F4F4F;
font-weight: bold;
text-align: center;
width: 100%;
}
</style>
<?php
include('config.php');
if(isset($_GET['studentID']))
{
$id=$_GET['studentID'];
if(isset($_POST['submit']))
{
$studentID=$_POST['studentID'];
$studentName=$_POST['studentName'];
$studentFaculty=$_POST['studentFaculty'];
$studentEmail=$_POST['studentEmail'];


$query3=mysql_query("update users set studentName='$studentName', studentFaculty='$studentFaculty', studentEmail='$studentEmail' where studentID='$studentID'");
if($query3)
{
header('location:view.php');
}
}
$query1=mysql_query("select * from student where studentID='$studentID'");
$query2=mysql_fetch_array($query1);
?>
</br></br>
</br></br>
</br></br>
</br></br>
</br></br>

<form method="post" action="" align = 'center'>
<input type="hidden" name="language" id="language" value="2" />
<table border="0" cellpadding="10" cellspacing="0" width="900" align="center">
<tr class="tableheader">
<td align="center" colspan="2">UPDATE</td>
</tr>
<tr class="tablerow">
<td align="left" class="td">Student ID</td>
<td><input type="text" name="studentID" id="studentID"value="<?php echo $query2['studentID']; ?>" /><br /><br /></td>
</tr>
<tr class="tablerow">
<td align="left" class="td">Student Name</td>
<td><input type="text" name="studentName" value="<?php echo $query2['studentName']; ?>" /><br /><br /></td>
</tr>
<tr class="tablerow">
<td align="left" class="td">Student Faculty</td>
<td><input type="text" name="studentFaculty" value="<?php echo $query2['studentFaculty']; ?>" /><br /><br /></td>
</tr>
<tr class="tablerow">
<td align="left" class="td">Student Email</td>
<td><input type="text" name="studentEmail" id="studentEmail" value="<?php echo $query2['studentEmail']; ?>" /><br /><br /></td>
</tr>
<tr class="tablerow">
<td align="left" class="td"></td>
<td><input type="submit" name="submit" value="update" /</td>
</tr>

<br />

</form>
<?php
}
?>
</body>
</html>