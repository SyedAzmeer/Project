

<html>


<head>
<?php
session_start();

if(!$_SESSION['studentID']){
	
	header("location: login.html");
}
?>

<link rel="stylesheet" type="text/css" href="navigationstyle.css">


</head>



<div id="header">  <img src='http://www.ump.edu.my/download/logo-rasmi-ump.png' align='middle' width='20%' height='15%'><img src='https://terengganutimes.com/wp-content/uploads/2014/10/ADUAN_01.png' align='right' width='20%' height='15%'><br/><br/></div>

<body>

<ul class="topnav" id="myTopnav">

<?php
if($_SESSION["studentID"]) {
?>
<li><a class="active" >Welcome <?php echo $_SESSION["studentName"]; ?> to E-aduan</a><br></li>
<?php
}
?>
   <li><a href="http://localhost/xampp/project/home.php">Homepage</a></li>
  <li><a href="http://localhost/xampp/project/status.php">View Status</a></li>
  <li><a href="http://localhost/xampp/project/view.php">Update List</a></li>
  <li><a href="http://localhost/xampp/project/FAQ.html">FAQ</a></li>
  <li><a href="logout-process.php">LOG OUT</a></li>
  
  <li class="icon">
    <a href="javascript:void(0);" style="font-size:15px;" onclick="myFunction()">☰</a>
  </li>
</ul>

<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>

</body>

<style>
table{
	border-collapse: collapse;
    width: 100%;
}

 th, td {
    text-align: left;
    padding: 8px;
	 
}
tr:nth-child(even){background-color: #f2f2f2}
th {
    background-color: #4CAF50;
    color: white;
}
</style>
<?php
$servername = "localhost";
$username = "syedazmeer";
$password = "123456";
$dbname = "aduan";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM student";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
	echo "<h3>LIST OF STUDENT</h3>";
     echo "<table>";
	 echo"<tr>";
	 echo"<th>ID</th>";
	 echo "<th>Name</th>";
	 echo "<th>Faculty</th>";
	 echo "<th>Email</th>";
	 echo"</tr>";
     // output data of each row
     while($row = $result->fetch_assoc()) {
		 
         echo "<tr>";
		 echo "<td>" . $row["studentID"]. "</td>";
		 echo "<td>" . $row["studentName"]."</td>";
		 echo "<td>" . $row["studentFaculty"]."</td>";
		 echo "<td>" . $row["studentEmail"]."</td>";
		 echo "<td><a href='update.php?studentID=".$row['studentID']."'>Edit</a></td>";
		 echo "<td><a href='delete.php?studentID=".$row['studentID']."'>Delete</a></td><tr>";
		 echo "</tr>";
     }
     echo "</table>";
} else {
     echo "0 results";
}

$conn->close();
?> 
 
</div>

<div id="footer">







</div>

  </body></html>
