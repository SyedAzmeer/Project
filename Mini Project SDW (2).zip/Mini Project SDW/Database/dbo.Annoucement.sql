﻿CREATE TABLE [dbo].[Annoucement] (
    [ID]                  INT           IDENTITY (1, 1) NOT NULL,
    [titleAnnounce]       NVARCHAR (50) NOT NULL,
    [category]            NVARCHAR (50) NOT NULL,
    [priority]            NCHAR (10)    NOT NULL,
    [day]                 NCHAR (10)    NOT NULL,
    [referenceLink]       NVARCHAR (50) NOT NULL,
    [descriptionAnnounce] NVARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([ID] ASC)
);

