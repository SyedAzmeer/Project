﻿CREATE TABLE [dbo].[OEintern] (
    [internmark]    NVARCHAR (50) NOT NULL,
    [interncomment] NVARCHAR (50) NOT NULL,
    [matricNo]      NVARCHAR (50) NOT NULL,
    [status]        NVARCHAR (50) NOT NULL,
    CONSTRAINT [FK_OEintern_registerStd] FOREIGN KEY ([matricNo]) REFERENCES [dbo].[registerStd] ([matricNo])
);

