﻿CREATE TABLE [dbo].[OElogbook] (
    [logbookmark]    NVARCHAR (50) NOT NULL,
    [logbookcomment] NVARCHAR (50) NOT NULL,
    [matricNo]       NVARCHAR (50) NOT NULL,
    [status]         NVARCHAR (50) NOT NULL,
    CONSTRAINT [FK_OElogbook_registerStd] FOREIGN KEY ([matricNo]) REFERENCES [dbo].[registerStd] ([matricNo])
);

