﻿CREATE TABLE [dbo].[OEpresentation] (
    [presentationmark] INT           NOT NULL,
    [matricNo]         NVARCHAR (50) NOT NULL,
    [status]           NVARCHAR (50) NOT NULL,
    CONSTRAINT [FK_OEpresentation_registerStd] FOREIGN KEY ([matricNo]) REFERENCES [dbo].[registerStd] ([matricNo])
);

