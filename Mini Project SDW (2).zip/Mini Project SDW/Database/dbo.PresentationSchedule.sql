﻿CREATE TABLE [dbo].[PresentationSchedule] (
    [matricNo]           NVARCHAR (50)  NOT NULL,
    [logbookresult]      INT            NOT NULL,
    [logbookcomment]     NVARCHAR (MAX) NULL,
    [internresult]       INT            NOT NULL,
    [interncomment]      NVARCHAR (MAX) NULL,
    [presentationresult] INT            NOT NULL,
    PRIMARY KEY CLUSTERED ([matricNo] ASC)
);

