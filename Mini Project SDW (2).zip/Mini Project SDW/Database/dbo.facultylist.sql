﻿CREATE TABLE [dbo].[facultylist] (
    [Matric_ID]  NVARCHAR (50) NOT NULL,
    [Name]       NVARCHAR (50) NOT NULL,
    [Company]    NVARCHAR (50) NOT NULL,
    [Location]   NVARCHAR (50) NOT NULL,
    [Supervisor] NVARCHAR (50) NOT NULL,
    [Date]       DATE          NOT NULL,
    PRIMARY KEY CLUSTERED ([Matric_ID] ASC)
);

