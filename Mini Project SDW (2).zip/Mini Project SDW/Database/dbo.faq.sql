﻿CREATE TABLE [dbo].[faq] (
    [question] NVARCHAR (MAX) NOT NULL,
    [answer]   NVARCHAR (MAX) NOT NULL
);

