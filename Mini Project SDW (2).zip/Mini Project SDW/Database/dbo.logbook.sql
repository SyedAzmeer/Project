﻿CREATE TABLE [dbo].[logbook] (
    [week]        NVARCHAR (50)  NOT NULL,
    [day]         NVARCHAR (50)  NOT NULL,
    [date]        DATE           NOT NULL,
    [title]       NVARCHAR (MAX) NOT NULL,
    [description] NVARCHAR (MAX) NOT NULL,
    [attach]      NVARCHAR (MAX) NOT NULL,
    [matricNo]    NVARCHAR (50)  NOT NULL,
    CONSTRAINT [PK_logbook] PRIMARY KEY CLUSTERED ([date] ASC),
    CONSTRAINT [FK_logbook_registerStd] FOREIGN KEY ([matricNo]) REFERENCES [dbo].[registerStd] ([matricNo])
);

