﻿CREATE TABLE [dbo].[mps] (
    [date]  DATE          NOT NULL,
    [time]  TIME (7)      NOT NULL,
    [venue] NVARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([date] ASC)
);

