﻿CREATE TABLE [dbo].[registerSV] (
    [nameSV]   NVARCHAR (50) NOT NULL,
    [email]    NVARCHAR (50) NOT NULL,
    [phone_no] NVARCHAR (50) NOT NULL,
    [password] NVARCHAR (50) NOT NULL,
    [username] NCHAR (10)    NOT NULL,
    PRIMARY KEY CLUSTERED ([username] ASC)
);

