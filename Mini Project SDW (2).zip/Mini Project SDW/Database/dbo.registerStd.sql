﻿CREATE TABLE [dbo].[registerStd] (
    [nameStd]       NVARCHAR (50) NOT NULL,
    [matricNo]      NVARCHAR (50) NOT NULL,
    [email]         NVARCHAR (50) NOT NULL,
    [phone_no]      NVARCHAR (50) NOT NULL,
    [company_name]  NVARCHAR (50) NOT NULL,
    [company_state] NVARCHAR (50) NOT NULL,
    [password]      NVARCHAR (50) NOT NULL,
    [periodfrom]    NVARCHAR (50) NOT NULL,
    [periodto]      NVARCHAR (50) NOT NULL,
    PRIMARY KEY CLUSTERED ([matricNo] ASC)
);

