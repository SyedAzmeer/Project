﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Assign_AssignSVForm_View : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Pavilion\Documents\IMS.mdf;Integrated Security=True;Connect Timeout=30");
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }

    

    protected void btnValid_Click(object sender, EventArgs e)
    {
        var matric = txtmatricno.Text;
        var status1 = "ASSIGNED";

        conn.Open();
        SqlCommand cmd = conn.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "INSERT INTO [facultylist] VALUES ('" + matric + "','" + txtfaculty.Text + "','" + dropSV.SelectedItem.Text + "','" + txtCal.Text + "','" + status1 + "')" ;
        //cmd.CommandText = "INSERT INTO [facultylist] VALUES ('" + matric + "','" + txtfaculty.Text + "','" + dropSV.SelectedItem.Text + "','" + txtCal.Text + "','" + status1 + "')";
        SqlCommand cmd1 = new SqlCommand("UPDATE registerStd SET status = @a1 WHERE matricNo = @a7", conn);

        cmd1.Parameters.AddWithValue("a1", status1);
        cmd1.Parameters.AddWithValue("a7", matric);
        cmd.ExecuteNonQuery(); 
        cmd1.ExecuteNonQuery();
        conn.Close();

        //conn.Open();
        ////SqlCommand cmd = conn.CreateCommand();
        ////cmd.CommandType = CommandType.Text;

        

        //cmd.ExecuteNonQuery();

        Response.Write("<script type=\"text/javascript\">alert('Validation Completed!');</script>");
        Response.Redirect("~/Assign/AssignSVMain_View.aspx");
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Assign/AssignSVMain_View.aspx");
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
            getData(this.User.Identity.Name);
    }
    private void getData(string user)
    {
        if (searchlist.SelectedValue == "MatricNo")
        {
            //var matricNo = Session["MatricNumber"] + "";
            var matricNo = txtkeyword.Text;
            DataTable dt = new DataTable();
            conn.Open();
            SqlCommand sqlCmd = new SqlCommand("SELECT * from registerStd WHERE  [matricNo]= @matricNo", conn);
            SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);

            sqlCmd.Parameters.AddWithValue("@matricNo", matricNo);
            sqlDa.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                txtname.Text = dt.Rows[0]["nameStd"].ToString();
                txtmatricno.Text = dt.Rows[0]["matricNo"].ToString();//Where ColumnName is the Field from the DB that you want to display
                txtcompany.Text = dt.Rows[0]["company_name"].ToString();
                txtloc.Text = dt.Rows[0]["company_state"].ToString();
                txtfaculty.Text = dt.Rows[0]["faculty"].ToString();
            }
            conn.Close();
        }
        else if (searchlist.SelectedValue == "Name")
        {
            //var matricNo = Session["MatricNumber"] + "";
            var name = txtkeyword.Text;
            DataTable dt = new DataTable();
            conn.Open();
            SqlCommand sqlCmd = new SqlCommand("SELECT * from registerStd WHERE  [nameStd]= @name", conn);
            SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);

            sqlCmd.Parameters.AddWithValue("@name", name);
            sqlDa.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                txtname.Text = dt.Rows[0]["nameStd"].ToString();
                txtmatricno.Text = dt.Rows[0]["matricNo"].ToString();//Where ColumnName is the Field from the DB that you want to display
                txtcompany.Text = dt.Rows[0]["company_name"].ToString();
                txtloc.Text = dt.Rows[0]["company_state"].ToString();
                txtfaculty.Text = dt.Rows[0]["faculty"].ToString();
            }
            conn.Close();
        }

    }
}
