﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

public partial class View_AssignSVMain_View : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        //dropArea.AutoPostBack = true;
        //dropfaculty.AutoPostBack = true;
        //GridView1.AutoGenerateColumns = true;

        SqlDataSource sds = new SqlDataSource();
        //get connection string from application's web.config file
        sds.ConnectionString = ConfigurationManager.ConnectionStrings["IMSConnectionString"].ToString();
        //create parameters with specified name and values 
        sds.SelectParameters.Add("Faculty", TypeCode.String, this.dropfaculty.SelectedValue);
        sds.SelectParameters.Add("Location", TypeCode.String, this.dropArea.SelectedValue);
        //set the sql string to retrive data from the database
        //sds.SelectCommand = "SELECT * FROM [facultylist] WHERE[Faculty] = @Faculty AND SELECT * FROM [registerStd] WHERE[company_state] = @Location";
        sds.SelectCommand = "SELECT registerStd.matricNo, registerStd.nameStd, registerStd.company_state, registerStd.company_name, facultylist.Supervisor, facultylist.Date FROM registerStd INNER JOIN facultylist ON registerStd.matricNo = facultylist.matricNo WHERE registerStd.company_state = @Location AND registerStd.faculty = @Faculty ";
        //retrive data
        DataView dv = (DataView)sds.Select(DataSourceSelectArguments.Empty);
        if (dv.Count == 0)
        {
            this.Label1.Visible = true;
            GridView1.Visible = false;
            this.Label1.Text = "No Data Found";
            return;
        }
        else
        {

            this.Label1.Visible = false;
            GridView1.DataSource = sds;
            GridView1.DataBind();
        }
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        //Response.Redirect("AssignSVForm_View.aspx");
    }

    protected void gridFKASAKL_SelectedIndexChanged(object sender, EventArgs e)
    {
        //Session["matric"] = gridFKASAKL.SelectedRow.Cells[1].Text;
        //Session["name"] = gridFKASAKL.SelectedRow.Cells[2].Text;
        //Session["location"] = gridFKASAKL.SelectedRow.Cells[3].Text;
        //Session["company"] = gridFKASAKL.SelectedRow.Cells[4].Text;
        //Session["supervisor"] = gridFKASAKL.SelectedRow.Cells[5].Text;
        //Session["date"] = gridFKASAKL.SelectedRow.Cells[6].Text;

        //Response.Redirect("AssignSVForm_View.aspx");
    }

    protected void gridFKASAPHG_SelectedIndexChanged(object sender, EventArgs e)
    {
        //Session["matric"] = gridFKASAPHG.SelectedRow.Cells[1].Text;
        //Session["name"] = gridFKASAPHG.SelectedRow.Cells[2].Text;
        //Session["location"] = gridFKASAPHG.SelectedRow.Cells[3].Text;
        //Session["company"] = gridFKASAPHG.SelectedRow.Cells[4].Text;
        //Session["supervisor"] = gridFKASAPHG.SelectedRow.Cells[5].Text;
        //Session["date"] = gridFKASAPHG.SelectedRow.Cells[6].Text;

        //Response.Redirect("AssignSVForm_View.aspx");
    }

    protected void gridFSKKPKL_SelectedIndexChanged(object sender, EventArgs e)
    {
        //Session["matric"] = gridFSKKPKL.SelectedRow.Cells[1].Text;
        //Session["name"] = gridFSKKPKL.SelectedRow.Cells[2].Text;
        //Session["location"] = gridFSKKPKL.SelectedRow.Cells[3].Text;
        //Session["company"] = gridFSKKPKL.SelectedRow.Cells[4].Text;
        //Session["supervisor"] = gridFSKKPKL.SelectedRow.Cells[5].Text;
        //Session["date"] = gridFSKKPKL.SelectedRow.Cells[6].Text;

        //Response.Redirect("AssignSVForm_View.aspx");
    }

    protected void gridFSKKPPHG_SelectedIndexChanged(object sender, EventArgs e)
    {
        //Session["matric"] = gridFSKKPPHG.SelectedRow.Cells[1].Text;
        //Session["name"] = gridFSKKPPHG.SelectedRow.Cells[2].Text;
        //Session["location"] = gridFSKKPPHG.SelectedRow.Cells[3].Text;
        //Session["company"] = gridFSKKPPHG.SelectedRow.Cells[4].Text;
        //Session["supervisor"] = gridFSKKPPHG.SelectedRow.Cells[5].Text;
        //Session["date"] = gridFSKKPPHG.SelectedRow.Cells[6].Text;

        //Response.Redirect("AssignSVForm_View.aspx");
    }

    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        Session["matric"] = GridView1.SelectedRow.Cells[1].Text;
        Session["name"] = GridView1.SelectedRow.Cells[2].Text;
        Session["faculty"] = GridView1.SelectedRow.Cells[3].Text;
        Session["location"] = GridView1.SelectedRow.Cells[4].Text;
        Session["company"] = GridView1.SelectedRow.Cells[5].Text;
        Session["supervisor"] = GridView1.SelectedRow.Cells[6].Text;
        //Session["date"] = GridView1.SelectedRow.Cells[7].Text;

        Response.Redirect("~/Assign/AssignUpdateSVForm_View.aspx");
    }

    protected void btnnew_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Assign/AssignSVForm_View.aspx");
    }
}