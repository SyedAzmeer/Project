﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class View_AssignSVMain_View : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Pavilion\Documents\IMS.mdf;Integrated Security=True;Connect Timeout=30");
    protected void Page_Load(object sender, EventArgs e)
    {
        dropSVEdit.Visible = false;
        txtCalEdit.Visible = false;
        if (!Page.IsPostBack)
        {
            getData(this.User.Identity.Name);
            getData1(this.User.Identity.Name);
        }


    }

    private void getData(string user)
    {
        var matric = Session["matric"] + "";

        DataTable dt = new DataTable();
        conn.Open();
        SqlCommand sqlCmd = new SqlCommand("SELECT * from registerStd WHERE  [matricNo]= @matric", conn);
        SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);

        sqlCmd.Parameters.AddWithValue("@matric", matric);
        sqlDa.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            txtName.Text = dt.Rows[0]["nameStd"].ToString();
            txtMatric.Text = dt.Rows[0]["matricNo"].ToString();//Where ColumnName is the Field from the DB that you want to display
            txtCompany.Text = dt.Rows[0]["company_name"].ToString();
            txtLoc.Text = dt.Rows[0]["company_state"].ToString();
            txtfaculty.Text = dt.Rows[0]["faculty"].ToString();
        }
        conn.Close();
    }

    private void getData1(string user)
    {
        var matric = Session["MatricNumber"] + "";

        DataTable dt = new DataTable();
        conn.Open();
        SqlCommand sqlCmd = new SqlCommand("SELECT * from facultylist WHERE  [matricNo]= @matric", conn);
        SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);

        sqlCmd.Parameters.AddWithValue("@matric", matric);
        sqlDa.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            //txtfaculty.Text = dt.Rows[0]["faculty"].ToString();
            txtSV.Text = dt.Rows[0]["Supervisor"].ToString();
            txtCal.Text = dt.Rows[0]["Date"].ToString();

        }
        conn.Close();
    }


    protected void btnValid_Click(object sender, EventArgs e)
    {
        var matric = Session["matricNo"] + "";
     
       var faculty = txtfaculty.Text;
        if (txtSV.Text == "")
        {
            var sv = dropSVEdit.SelectedItem.Text;
            if (txtCal.Text == "")
            {
                var cal = txtCalEdit.Text;
                SqlCommand cmd = new SqlCommand("UPDATE facultylist SET  matricNo = @a1, faculty = @a2,  Supervisor = @a3,  Date = @a4 WHERE matricNo =@a7", conn);

                cmd.Parameters.AddWithValue("a1", matric);
                cmd.Parameters.AddWithValue("a2", faculty);
                cmd.Parameters.AddWithValue("a3", sv);
                cmd.Parameters.AddWithValue("a4", cal);
                cmd.Parameters.AddWithValue("a7", matric);

                cmd.ExecuteNonQuery();
                Response.Redirect("~/Manage_Logbook/LogbookMainStd.aspx");
                Response.Write("<script type=\"text/javascript\">alert('Validation Completed!');</script>");
            }
            else
            {
                var cal = txtCal.Text;
                SqlCommand cmd = new SqlCommand("UPDATE facultylist SET  matricNo = @a1, faculty = @a2,  Supervisor = @a3,  Date = @a4 WHERE matricNo =@a7", conn);

                cmd.Parameters.AddWithValue("a1", matric);
                cmd.Parameters.AddWithValue("a2", faculty);
                cmd.Parameters.AddWithValue("a3", sv);
                cmd.Parameters.AddWithValue("a4", cal);
                cmd.Parameters.AddWithValue("a7", matric);

                cmd.ExecuteNonQuery();
                Response.Redirect("~/Manage_Logbook/LogbookMainStd.aspx");
                Response.Write("<script type=\"text/javascript\">alert('Validation Completed!');</script>");
            }
        }
        
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Assign/AssignSVMain_View.aspx");
    }

    protected void btnEditSV_Click(object sender, EventArgs e)
    {
        btnEditSV.Visible = false;
        txtSV.Visible = false;
        dropSVEdit.Visible = true;
        
    }

    protected void btnEditDate_Click(object sender, EventArgs e)
    {
        btnEditDate.Visible = false;
        txtCal.Visible = false;
        txtCalEdit.Visible = true;
    }

    protected void txtMatric_TextChanged(object sender, EventArgs e)
    {

    }
}