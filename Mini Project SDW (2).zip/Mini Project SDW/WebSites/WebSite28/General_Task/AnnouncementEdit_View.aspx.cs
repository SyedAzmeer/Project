﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class General_Task_AnnouncementEdit_View : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            getData(this.User.Identity.Name);
        }
    }

    private void getData(string user)
    {
        var titleAnnounce = Session["titleAnnounce"] + "";
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["IMSConnectionString"].ConnectionString);
        DataTable dt = new DataTable();
        conn.Open();
        SqlCommand sqlCmd = new SqlCommand("SELECT titleAnnounce,category,priority,day,referenceLink,descriptionAnnounce from Annoucement WHERE  [titleAnnounce]= @titleAnnounce", conn);
        SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);

        sqlCmd.Parameters.AddWithValue("@titleAnnounce", titleAnnounce);
        sqlDa.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            txt_titleAnnounce.Text = dt.Rows[0]["titleAnnounce"].ToString();
            DropDown_category.SelectedItem.Text = dt.Rows[0]["category"].ToString();//Where ColumnName is the Field from the DB that you want to display
            DropDown_priority.SelectedItem.Text = dt.Rows[0]["priority"].ToString();
            DropDown_day.SelectedItem.Text = dt.Rows[0]["day"].ToString();
            txt_referenceLink.Text = dt.Rows[0]["referenceLink"].ToString();
            txt_descriptionAnnounce.Text = dt.Rows[0]["descriptionAnnounce"].ToString();
        }
        conn.Close();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["IMSConnectionString"].ConnectionString);

        conn.Open();
        //SqlCommand cmd = conn.CreateCommand();
        //cmd.CommandType = CommandType.Text;

        SqlCommand cmd = new SqlCommand("UPDATE Annoucement SET  category = @category, priority = @priority, day = @day, referenceLink = @referenceLink, descriptionAnnounce = @descriptionAnnounce WHERE titleAnnounce =@titleAnnounce", conn);

        cmd.Parameters.AddWithValue("titleAnnounce", txt_titleAnnounce.Text);
        cmd.Parameters.AddWithValue("category", DropDown_category.SelectedItem.Text);
        cmd.Parameters.AddWithValue("priority", DropDown_priority.SelectedItem.Text);
        cmd.Parameters.AddWithValue("day", DropDown_day.SelectedItem.Text);
        cmd.Parameters.AddWithValue("referenceLink", txt_referenceLink.Text);
        cmd.Parameters.AddWithValue("descriptionAnnounce", txt_descriptionAnnounce.Text);

        cmd.ExecuteNonQuery();
        //Response.Write("<script type=\"text/javascript\">alert('Announcement has been update');</script>");
        conn.Close();

        Response.Redirect("~/General_Task/AnnouncementMainSV_View.aspx");
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["IMSConnectionString"].ConnectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand("DELETE FROM Annoucement WHERE titleAnnounce=@titleAnnounce", conn);
        cmd.Parameters.AddWithValue("@titleAnnounce", txt_titleAnnounce.Text);
        cmd.ExecuteNonQuery();
        conn.Close();
        Response.Output.Write("\nhi goood morning!");//works fine

        Response.Redirect("~/General_Task/AnnouncementMainSV_View.aspx");
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/General_Task/AnnouncementMainSV_View.aspx");
    }
}