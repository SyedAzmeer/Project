﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class AnnouncementForm_View : System.Web.UI.Page
{

    //SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=IMS;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        //txt_titleAnnounce.Text = Session["title"] + "";
        //DropDown_category.SelectedItem.Text = Session["category"] + "";
        //DropDown_priority.SelectedItem.Text = Session["priority"] + "";
        //DropDown_day.SelectedItem.Text = Session["day"] + "";
        //txt_referenceLink.Text = Session["referencelink"] + "";
        //txt_descriptionAnnounce.Text = Session["description"] + "";
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["IMSConnectionString"].ConnectionString);
        conn.Open();
        string insertQuery = "insert into Annoucement(titleAnnounce,category,priority,day,referenceLink,descriptionAnnounce)values (@titleAnnounce,@category,@priority,@day,@referenceLink,@descriptionAnnounce)";
        SqlCommand cmd = new SqlCommand(insertQuery, conn);
        cmd.Parameters.AddWithValue("@titleAnnounce", txt_titleAnnounce.Text);
        cmd.Parameters.AddWithValue("@category", DropDown_category.SelectedItem.Text);
        cmd.Parameters.AddWithValue("@priority", DropDown_priority.SelectedItem.Text);
        cmd.Parameters.AddWithValue("@day", DropDown_day.SelectedItem.Text);
        cmd.Parameters.AddWithValue("@referenceLink", txt_referenceLink.Text);
        cmd.Parameters.AddWithValue("@descriptionAnnounce", txt_descriptionAnnounce.Text);
        cmd.ExecuteNonQuery();
        
        conn.Close();
        //conn.Open();
        //SqlCommand cmd = conn.CreateCommand();
        //cmd.CommandType = CommandType.Text;
        //cmd.CommandText = "INSERT INTO [Announcement] VALUES ('" + txt_titleAnnounce.Text + "','" + DropDown_category.SelectedItem.Text + "','" + DropDown_day.SelectedItem.Text + "','" + txt_referenceLink.Text + "','" + txt_descriptionAnnounce.Text  + "')";
        //cmd.ExecuteNonQuery();
        //conn.Close();
        //Session["title"] = txt_titleAnnounce.Text;
        //Session["description"] = txt_descriptionAnnounce.Text;
        Response.Redirect("~/General_Task/AnnouncementMainSV_View.aspx");
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/MainPage/MainPageSV_View.aspx");
    }
}