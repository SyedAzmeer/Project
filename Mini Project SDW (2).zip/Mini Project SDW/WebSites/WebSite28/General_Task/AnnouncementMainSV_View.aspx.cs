﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class General_Task_AnnouncementMainSV_View : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["titleAnnounce"] = GridView2.SelectedRow.Cells[0].Text;
        //Session["description"] = GridView2.SelectedRow.Cells[5].Text;
        Response.Redirect("~/General_Task/AnnouncementEdit_View.aspx");
        //SqlCommand cmd;
        //SqlConnection conn;
        //SqlDataAdapter da;
        //conn = new SqlConnection(@"Data Source=(LocalDB)\v11.0;Initial Catalog=Books;Integrated Security=True");
        //conn.Open();

        //cmd = new SqlCommand("DELETE FROM Info WHERE (email = ' " + TBemail.Text + " ')", conn);
        //cmd.ExecuteNonQuery();
        //LBLmsg.Text = "Data successfully deleted";
        //TBemail.Text = "  ";
        //conn.Close();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/General_Task/AnnouncementForm_View.aspx");
    }
}