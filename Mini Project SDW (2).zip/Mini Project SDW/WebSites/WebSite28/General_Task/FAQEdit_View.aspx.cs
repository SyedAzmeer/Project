﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class General_Task_FAQEdit_View : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            getData(this.User.Identity.Name);
        }
    }

    private void getData(string user)
    {
        var Question = Session["Question"] + "";
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["IMSConnectionString"].ConnectionString);
        DataTable dt = new DataTable();
        conn.Open();
        SqlCommand sqlCmd = new SqlCommand("SELECT Question,Answer from FAQ WHERE  [Question]= @Question", conn);
        SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);

        sqlCmd.Parameters.AddWithValue("@Question", Question);
        sqlDa.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            txt_question.Text = dt.Rows[0]["Question"].ToString();
            txt_answer.Text = dt.Rows[0]["Answer"].ToString();//Where ColumnName is the Field from the DB that you want to display
        }
        conn.Close();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["IMSConnectionString"].ConnectionString);

        conn.Open();
        //SqlCommand cmd = conn.CreateCommand();
        //cmd.CommandType = CommandType.Text;

        SqlCommand cmd = new SqlCommand("UPDATE FAQ SET  Question = @Question, Answer = @Answer WHERE Question =@Question", conn);

        cmd.Parameters.AddWithValue("Question", txt_question.Text);
        cmd.Parameters.AddWithValue("Answer", txt_answer.Text);


        cmd.ExecuteNonQuery();
        //Response.Write("<script type=\"text/javascript\">alert('Announcement has been update');</script>");
        conn.Close();

        Response.Redirect("~/General_Task/FAQMainSV_View.aspx");
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["IMSConnectionString"].ConnectionString);
        conn.Open();
        SqlCommand cmd = new SqlCommand("DELETE FROM FAQ WHERE Question=@Question", conn);
        cmd.Parameters.AddWithValue("@Question", txt_question.Text);
        cmd.ExecuteNonQuery();
        conn.Close();
        Response.Redirect("~/General_Task/FAQMainSV_View.aspx");
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/General_Task/FAQMainSV_View.aspx");
    }
}