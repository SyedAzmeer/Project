﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class General_Task_FAQMainStd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["IMSConnectionString"].ConnectionString);
        con.Open();
        SqlDataAdapter da = new SqlDataAdapter("Select Question,Answer from FAQ where Question like'" + TextBox1.Text + "%'", con);
        //string text = ((TextBox)sender).Text;
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            GridView2.DataSource = ds.Tables[0];
            GridView2.DataBind();
            GridView2.Visible = true;
            GridView1.Visible = false;
            Label1.Visible = false;
        }
        else
        {
            GridView1.Visible = true;
            GridView2.Visible = false;
            Label1.Visible = true;
            Label1.Text = "No Record Found";
        }
    }
}