﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class General_Task_GenerateReportFinalLogbook : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Button6.Visible = false;
        Button4.Visible = true;
        if (!Page.IsPostBack)
        {
            getData(this.User.Identity.Name);
        }
    }

    private void getData(string user)
    {
        var date = Session["date"] + "";
        //var description = Session["description"] + "";
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["IMSConnectionString"].ConnectionString);
        DataTable dt = new DataTable();
        conn.Open();
        SqlCommand sqlCmd = new SqlCommand("SELECT logbook.date,logbook.title,logbook.description,logbook.attach,logbook.matricNo,registerStd.nameStd FROM logbook INNER JOIN registerStd ON logbook.matricNo = registerStd.matricNo WHERE [date]= @date", conn);
        SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);

        sqlCmd.Parameters.AddWithValue("@date", date);
        sqlDa.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            lbl_matricNo.Text = dt.Rows[0]["matricNo"].ToString();
            lbl_nameStd.Text = dt.Rows[0]["nameStd"].ToString();//Where ColumnName is the Field from the DB that you want to display
            lbl_date.Text = dt.Rows[0]["date"].ToString();
            lbl_title.Text = dt.Rows[0]["title"].ToString();
            lbl_description.Text = dt.Rows[0]["description"].ToString();
            lbl_attachment.Text = dt.Rows[0]["attach"].ToString();

        }
        conn.Close();
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        Button6.Visible = true;
        Button4.Visible = false;
    }

    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/General_Task/GenerateReportMain_View.aspx");
    }
}