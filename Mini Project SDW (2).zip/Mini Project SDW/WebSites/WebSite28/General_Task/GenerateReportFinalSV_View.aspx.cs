﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class GenerateReportFinalSV_View : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lbl_matricNo.Text = Session["matricNo"] + "";
        lbl_nameStd.Text = Session["nameStd"] + "";
        lbl_company_name.Text = Session["company_name"] + "";
        lbl_companyState.Text = Session["company_state"] + "";
        lbl_facultyStd.Text = Session["faculty"] + " ";
        lbl_nameSV.Text = Session["nameSV"] + " ";
        lbl_Date.Text = Session["date"] + " ";
        Button6.Visible = false;
        Button4.Visible = true;
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        Button6.Visible = true;
        Button4.Visible = false;
    }

    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/General_Task/GenerateReportMain_View.aspx");
    }
}