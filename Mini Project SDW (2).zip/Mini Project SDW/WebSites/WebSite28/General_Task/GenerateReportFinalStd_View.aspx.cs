﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class GenerateReportFinal_View : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //lbl_matricNo.Text = Session["matricNo"] + "";
        //lbl_nameStd.Text = Session["nameStd"] + "";
        //lbl_company_name.Text = Session["company_name"] + "";
        //lbl_company_state.Text = Session["company_state"] + "";
        //lbl_period.Text = Session["PerionFrom"]  + " - " + Session["PeriodTo"] + " ";
        Button6.Visible = false;
        Button4.Visible = true;

        if (!Page.IsPostBack)
        {
            getData(this.User.Identity.Name);
        }
    }

    private void getData(string user)
    {
        var matricNo = Session["MatricNumber"] + "";
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["IMSConnectionString"].ConnectionString);
        DataTable dt = new DataTable();
        conn.Open();
        SqlCommand sqlCmd = new SqlCommand("SELECT matricNo,nameStd,company_name,company_state,periodfrom,periodto from registerStd WHERE  [matricNo]= @matricNo", conn);
        SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);

        sqlCmd.Parameters.AddWithValue("@matricNo", matricNo);
        sqlDa.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            lbl_matricNo.Text = dt.Rows[0]["matricNo"].ToString();
            lbl_nameStd.Text = dt.Rows[0]["nameStd"].ToString();//Where ColumnName is the Field from the DB that you want to display
            lbl_company_name.Text = dt.Rows[0]["company_name"].ToString();
            lbl_company_state.Text = dt.Rows[0]["company_state"].ToString();
            lbl_period.Text = dt.Rows[0]["periodfrom"].ToString() + " - " + dt.Rows[0]["periodto"].ToString(); 

        }
        conn.Close();
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        Button6.Visible = true;
        Button4.Visible = false;
    }

    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/General_Task/GenerateReportMain_View.aspx");
    }
}