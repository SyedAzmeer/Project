﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class GenerateReportMain_View : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        var status = Session["Status1"] + "";
        if(status == "Student")
        {
            btn_PStdStatus.Visible = false;
            btn_AssignSV.Visible = false;
        }
        else if (status == "Faculty Supervisor")
        {
            btn_PStdStatus.Visible = false;
            btn_AssignSV.Visible = false;
        }
        else if (status == "Coordinator")
        {
             btn_reportLogbook.Visible = false;
        }
        else
        {
            btn_PStdStatus.Visible = false;
        }
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        var status = Session["Status1"] + "";
        if (status == "Student")
        {
            Response.Redirect("~/General_Task/GenerateReportFinalStd_View.aspx");
        }
        else
        {
            Response.Redirect("~/General_Task/ViewGenerateReportStd_View.aspx");
        }
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/General_Task/ViewGenerateReportPStd_View.aspx");
    }

    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/General_Task/ViewGenerateReportSV_View.aspx");
    }

    protected void btn_reportLogbook_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/General_Task/ViewGenerateReportLogbook_View.aspx");
    }
}