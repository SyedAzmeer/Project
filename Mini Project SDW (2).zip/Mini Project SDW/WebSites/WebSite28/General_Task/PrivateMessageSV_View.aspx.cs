﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class General_Task_PrivateMessageSV_View : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lbl_nameSV.Text = Session["UsernameSV"] + "";
        lbl_textStd.Text = Session["message"] + "";
    }

    protected void btn_Send_Click(object sender, ImageClickEventArgs e)
    {
        ViewState["message"] = txt_Message.Text;
        Session["message"] = txt_Message.Text;

        System.Threading.Thread.Sleep(1000);
        lbl_textSV.Text = ViewState["message"] + " ";
    }
}