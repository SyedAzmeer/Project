﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class General_Task_ViewGenerateReportLogbook_View : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            getData(this.User.Identity.Name);
        }
    }

    private void getData(string user)
    {
        var matricNo = Session["MatricNumber"] + "";
        //SqlDataSource sds = new SqlDataSource();
        ////get connection string from application's web.config file
        //sds.ConnectionString = ConfigurationManager.ConnectionStrings["IMSConnectionString"].ToString();
        ////create parameters with specified name and values 
        //sds.SelectParameters.Add("matricNo", TypeCode.String,matricNo);
        ////set the sql string to retrive data from the database
        ////sds.SelectCommand = "SELECT * FROM [facultylist] WHERE[Faculty] = @Faculty AND SELECT * FROM [registerStd] WHERE[company_state] = @Location";
        //sds.SelectCommand = "SELECT week, day, date, title, description, attach FROM logbook WHERE matricNo = @matricNo";
        ////retrive data
        //DataView dv = (DataView)sds.Select(DataSourceSelectArguments.Empty);
        //if (dv.Count == 0)
        //{
        //    this.Label1.Visible = true;
        //    GridView1.Visible = false;
        //    this.Label1.Text = "No Data Found";
        //    return;
        //}
        //else
        //{

        //    this.Label1.Visible = false;
        //    GridView1.DataSource = sds;
        //    //GridView1.DataBind();
        //}
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["IMSConnectionString"].ConnectionString);
        con.Open();
        SqlDataAdapter da = new SqlDataAdapter("Select date,description,attach from logbook where matricNo like'" + matricNo + "%'", con);
        //string text = ((TextBox)sender).Text;
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
            //Label2.Visible = false;
        }
        else
        {
            //Label2.Visible = true;
            //Label2.Text = "No Record Found";
        }
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        Session["date"] = GridView1.SelectedRow.Cells[1].Text;
        Session["description"] = GridView1.SelectedRow.Cells[2].Text;
        Response.Redirect("~/General_Task/GenerateReportFinalLogbook.aspx");
    }

    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/General_Task/GenerateReportMain_View.aspx");
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}