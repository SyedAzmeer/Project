﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ViewGenerateReportPStd_View : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/General_Task/GenerateReportFinalPStd_View.aspx");
    }

    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/General_Task/GenerateReportMain_View.aspx");
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["nameStd"] = GridView1.SelectedRow.Cells[0].Text;
        Session["matricNo"] = GridView1.SelectedRow.Cells[1].Text;
        Session["company_name"] = GridView1.SelectedRow.Cells[4].Text;
        Session["company_state"] = GridView1.SelectedRow.Cells[5].Text;
        Session["PerionFrom"] = GridView1.SelectedRow.Cells[6].Text;
        Session["PeriodTo"] = GridView1.SelectedRow.Cells[7].Text;
    }
}