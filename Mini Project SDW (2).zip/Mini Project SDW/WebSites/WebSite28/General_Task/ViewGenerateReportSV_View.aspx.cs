﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class ViewGenerateReportSV : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/General_Task/GenerateReportFinalSV_View.aspx");
    }

    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/General_Task/GenerateReportMain_View.aspx");
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["matricNo"] = GridView1.SelectedRow.Cells[0].Text;
        Session["nameStd"] = GridView1.SelectedRow.Cells[1].Text;
        Session["company_name"] = GridView1.SelectedRow.Cells[2].Text;
        Session["company_state"] = GridView1.SelectedRow.Cells[3].Text;
        Session["faculty"] = GridView1.SelectedRow.Cells[4].Text;
        Session["nameSV"] = GridView1.SelectedRow.Cells[5].Text;
        Session["date"] = GridView1.SelectedRow.Cells[6].Text;
    }
}