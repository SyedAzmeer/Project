﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Login_View : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Pavilion\Documents\IMS.mdf;Integrated Security=True;Connect Timeout=30");

    public object MessageBox { get; private set; }

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnregister_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Register/Register.aspx");
    }

    protected void btnlogin_Click(object sender, EventArgs e)
    {
        if (categorylist.SelectedItem.Text == "Student")
        {
            Session["Status1"] = categorylist.Text;
            Session["MatricNumber"] = txtusername.Text;
            conn.Open();
            string username = "select count(*) from registerStd where matricNo='" + txtusername.Text + "'";
            SqlCommand com = new SqlCommand(username, conn);
            int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
            if (temp == 1)
            {

                string checkPasswordQuery = "select password from registerStd where matricNo='" + txtusername.Text + "'";
                SqlCommand passComm = new SqlCommand(checkPasswordQuery, conn);
                string password = passComm.ExecuteScalar().ToString();

                if (password == txtpass.Text)
                {
                    Session["New"] = txtusername.Text;
                    Response.Write("<script type=\"text/javascript\">alert('Password is correct!');</script>"); 
                    Response.Redirect("~/MainPage/MainPage_View.aspx");

                }
                else
                {
                    Response.Write("<script type=\"text/javascript\">alert('Wrong username or password!');</script>");
                }
            }


            conn.Close();

        }
        else if(categorylist.SelectedItem.Text == "Faculty Supervisor")
        {
            Session["Status1"] = categorylist.Text;
            Session["UsernameSV"] = txtusername.Text;
            conn.Open();
            string username = "select count(*) from registerSV where username='" + txtusername.Text + "'";
            SqlCommand com = new SqlCommand(username, conn);
            int temp = Convert.ToInt32(com.ExecuteScalar().ToString());
            if (temp == 1)
            {

                string checkPasswordQuery = "select password from registerSV where username='" + txtusername.Text + "'";
                SqlCommand passComm = new SqlCommand(checkPasswordQuery, conn);
                string password = passComm.ExecuteScalar().ToString();

                if (password == txtpass.Text)
                {
                    Session["New"] = txtusername.Text;
                    Response.Write("<script type=\"text/javascript\">alert('Password is correct!');</script>");
                    Response.Redirect("~/MainPage/MainPageSV_View.aspx");

                }
                else
                {
                    Response.Write("<script type=\"text/javascript\">alert('Wrong username or password!');</script>");
                }
            }


            conn.Close();

        }
        else if(categorylist.Text == "Coordinator")
        {
            if(txtusername.Text == "Arfian" && txtpass.Text == "1234")
            {
                Session["Status1"] = categorylist.Text;
                Response.Write("<script type=\"text/javascript\">alert('Password is correct!');</script>");
                Response.Redirect("~/MainPage/MainPageCoordinator_View.aspx");
            }
            else
            {
                Response.Write("<script type=\"text/javascript\">alert('Wrong username or password!');</script>");
            }
        }
        else
        {
            if (txtusername.Text == "Steve" && txtpass.Text == "1234")
            {
                Session["Status1"] = categorylist.Text;
                Response.Write("<script type=\"text/javascript\">alert('Password is correct!');</script>");
                Response.Redirect("~/MainPage/MainPageIndustrySV_View.aspx");
            }
            else
            {
                Response.Write("<script type=\"text/javascript\">alert('Wrong username or password!');</script>");
            }
        }

         

    }



    protected void txtusername_TextChanged(object sender, EventArgs e)
    {

    }
}