﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

public partial class View_MPSCoordinatorMain_View : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnUnassign_Click(object sender, EventArgs e)
    {
        SqlDataSource sds = new SqlDataSource();
        //get connection string from application's web.config file
        sds.ConnectionString = ConfigurationManager.ConnectionStrings["IMSConnectionString"].ToString();
        //set the sql string to retrive data from the database
        sds.SelectCommand = "SELECT nameStd,matricNo,faculty,company_name,company_state FROM [registerStd] WHERE [statusmps] = '" + "UNASSIGNED" + "' AND  [status] = '" + "ASSIGNED" + "'";
        //retrive data
        DataView dv = (DataView)sds.Select(DataSourceSelectArguments.Empty);
        if (dv.Count == 0)
        {
            this.Label1.Visible = true;
            GridView5.Visible = false;
            this.Label1.Text = "No Data Found";
            return;
        }
        else
        {
            this.Label1.Visible = false;
            GridView5.DataSource = sds;
            GridView5.DataBind();
        }
    }

    protected void btnAssigned_Click(object sender, EventArgs e)
    {
        SqlDataSource sds = new SqlDataSource();
        //get connection string from application's web.config file
        sds.ConnectionString = ConfigurationManager.ConnectionStrings["IMSConnectionString"].ToString();
        //set the sql string to retrive data from the database
        sds.SelectCommand = "SELECT nameStd,matricNo,faculty,company_name,company_state FROM [registerStd] WHERE [statusmps] = '" + "ASSIGNED" + "' AND  [status] = '" + "ASSIGNED" + "'";
        //retrive data
        DataView dv = (DataView)sds.Select(DataSourceSelectArguments.Empty);
        if (dv.Count == 0)
        {
            this.Label1.Visible = true;
            GridView2.Visible = false;
            this.Label1.Text = "No Data Found";
            return;
        }
        else
        {
            this.Label1.Visible = false;
            GridView2.DataSource = sds;
            GridView2.DataBind();
        }
    }

    protected void btnRejected_Click(object sender, EventArgs e)
    {
        SqlDataSource sds = new SqlDataSource();
        //get connection string from application's web.config file
        sds.ConnectionString = ConfigurationManager.ConnectionStrings["IMSConnectionString"].ToString();
        //set the sql string to retrive data from the database
        sds.SelectCommand = "SELECT registerStd.nameStd,registerStd.matricNo,registerStd.faculty,registerStd.company_name,registerStd.company_state,mps.status FROM registerStd INNER JOIN mps ON registerStd.matricNo = mps.matricNo WHERE mps.status = '" + "REJECTED" + "'";
        //retrive data;
        //retrive data
        DataView dv = (DataView)sds.Select(DataSourceSelectArguments.Empty);
        if (dv.Count == 0)
        {
            this.Label1.Visible = true;
            GridView3.Visible = false;
            this.Label1.Text = "No Data Found";
            return;
        }
        else
        {
            this.Label1.Visible = false;
            GridView3.DataSource = sds;
            GridView3.DataBind();
        }
    }

    protected void btnAccepted_Click(object sender, EventArgs e)
    {
        SqlDataSource sds = new SqlDataSource();
        //get connection string from application's web.config file
        sds.ConnectionString = ConfigurationManager.ConnectionStrings["IMSConnectionString"].ToString();
        //set the sql string to retrive data from the database
        sds.SelectCommand = "SELECT registerStd.nameStd,registerStd.matricNo,registerStd.faculty,registerStd.company_name,registerStd.company_state,mps.status FROM registerStd INNER JOIN mps ON registerStd.matricNo = mps.matricNo WHERE mps.status = '" + "ACCEPTED" + "' ";
        //retrive data
        DataView dv = (DataView)sds.Select(DataSourceSelectArguments.Empty);
        if (dv.Count == 0)
        {
            this.Label1.Visible = true;
            GridView4.Visible = false;
            this.Label1.Text = "No Data Found";
            return;
        }
        else
        {
            this.Label1.Visible = false;
            GridView4.DataSource = sds;
            GridView4.DataBind();
        }
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["matric"] = GridView5.SelectedRow.Cells[2].Text;
        Session["name"] = GridView5.SelectedRow.Cells[1].Text;
        //Session["location"] = GridView1.SelectedRow.Cells[3].Text;
        //Session["sv"] = GridView1.SelectedRow.Cells[4].Text;

        Response.Redirect("~/MPS/MPSForm_View.aspx");
    }

    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["matric"] = GridView2.SelectedRow.Cells[1].Text;
        Session["name"] = GridView2.SelectedRow.Cells[2].Text;
        Session["location"] = GridView2.SelectedRow.Cells[3].Text;
        Session["sv"] = GridView2.SelectedRow.Cells[4].Text;

        Response.Redirect("~/MPS/MPSForm_View.aspx");
    }

    protected void GridView3_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["matric"] = GridView3.SelectedRow.Cells[1].Text;
        Session["name"] = GridView3.SelectedRow.Cells[2].Text;
        Session["location"] = GridView3.SelectedRow.Cells[3].Text;
        Session["sv"] = GridView3.SelectedRow.Cells[4].Text;

        Response.Redirect("~/MPS/MPSForm_View.aspx");
    }

    protected void GridView4_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["matric"] = GridView4.SelectedRow.Cells[1].Text;
        Session["name"] = GridView4.SelectedRow.Cells[2].Text;
        Session["location"] = GridView4.SelectedRow.Cells[3].Text;
        Session["sv"] = GridView4.SelectedRow.Cells[4].Text;

        Response.Redirect("~/MPS/MPSForm_View.aspx");
    }

    protected void btnview_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/MPS/ViewMPS_View.aspx");
    }

    protected void GridView5_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["matric"] = GridView5.SelectedRow.Cells[2].Text;
        Session["name"] = GridView5.SelectedRow.Cells[1].Text;
        //Session["location"] = GridView1.SelectedRow.Cells[3].Text;
        //Session["sv"] = GridView1.SelectedRow.Cells[4].Text;

        Response.Redirect("~/MPS/MPSForm_View.aspx");
    }
}