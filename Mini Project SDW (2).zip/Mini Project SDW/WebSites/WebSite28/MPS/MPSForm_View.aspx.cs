﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class View_MPSForm_View : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Pavilion\Documents\IMS.mdf;Integrated Security=True;Connect Timeout=30");

    protected void Page_Load(object sender, EventArgs e)
    {
        lblMatric.Text = Session["matric"].ToString();
        lblName.Text = Session["name"].ToString();
        //getData(this.User.Identity.Name);
    }


    //private void getData(string user)
    //{

    //    //var matricNo = Session["MatricNumber"] + "";
    //    var matricNo = Session["matric"] + "";
    //    DataTable dt = new DataTable();
    //    conn.Open();
    //    SqlCommand sqlCmd = new SqlCommand("SELECT * from registerStd WHERE  [matricNo]= @matricNo", conn);
    //    SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);

    //    sqlCmd.Parameters.AddWithValue("@matricNo", matricNo);
    //    sqlDa.Fill(dt);
    //    if (dt.Rows.Count > 0)
    //    {
    //        lblName.Text = dt.Rows[0]["nameStd"].ToString();
    //        lblMatric.Text = dt.Rows[0]["matricNo"].ToString();//Where ColumnName is the Field from the DB that you want to display

    //    }
    //    conn.Close();
    //}
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        var status = "ASSIGNED";
        var matric = lblMatric.Text;
        var status1 = "REJECT";
        //var date = calMPS.SelectedDate.ToShortDateString();
        conn.Open();
        SqlCommand cmd = conn.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "INSERT INTO [mps] VALUES ('" + calMPS.SelectedDate.ToShortDateString() + "','" + dropTime.SelectedItem.Text + "','" + dropVenue.SelectedItem.Text + "','" + matric + "','" + status1 + "')";
        SqlCommand cmd1 = new SqlCommand("UPDATE registerStd SET statusmps = @a1 WHERE matricNo = @a7", conn);

        cmd1.Parameters.AddWithValue("a1", status);
        cmd1.Parameters.AddWithValue("a7", matric);
        cmd.ExecuteNonQuery();
        cmd1.ExecuteNonQuery();

        conn.Close();
        cmd.Dispose();

        //Session["matric"] = lblMatric.Text;
        //Session["date"] = calMPS.SelectedDate.ToShortDateString();
        //Session["time"] = dropTime.Text;
        //Session["venue"] = dropVenue.Text;

        Response.Write("<script type=\"text/javascript\">alert('Successfully Assigned!');</script>");
        Response.Redirect("~/MPS/MPSForm_View.aspx");
    }

    

  

        
}