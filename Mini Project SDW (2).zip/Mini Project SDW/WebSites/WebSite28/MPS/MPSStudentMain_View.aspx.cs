﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class View_MPSStudentMain_View : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Pavilion\Documents\IMS.mdf;Integrated Security=True;Connect Timeout=30");

    protected void Page_Load(object sender, EventArgs e)
    {
        lblMatric.Text = Session["MatricNumber"] + "";
        //lblMatric.Text = Session["matric"].ToString();
        //lblDate.Text = Session["date"].ToString();
        //lblTime.Text = Session["time"].ToString();
        //lblVenue.Text = Session["venue"].ToString();
        
        if (!Page.IsPostBack)
        {
            getData(this.User.Identity.Name);
        }
    }

    private void getData(string user)
    {
        var matric = Session["MatricNumber"] + "";
        DataTable dt = new DataTable();
        //SqlConnection connection = new SqlConnection("IMSConnectionString");
        conn.Open();
        SqlCommand sqlCmd = new SqlCommand("SELECT * from mps WHERE matricNo = @matric", conn);
        SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);

        sqlCmd.Parameters.AddWithValue("@matric", matric);
        sqlDa.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            lblMatric.Text = dt.Rows[0]["matricNo"].ToString(); //Where ColumnName is the Field from the DB that you want to display
            lblDate.Text = dt.Rows[0]["date"].ToString();
            lblTime.Text = dt.Rows[0]["time"].ToString();
            lblVenue.Text = dt.Rows[0]["venue"].ToString();
        }
        conn.Close();
    }

    protected void btnAccept_Click(object sender, EventArgs e)
    {
        btnAccept.Visible = false;
        btnReject.Visible = false;
        var matric = lblMatric.Text;
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Pavilion\Documents\IMS.mdf;Integrated Security=True;Connect Timeout=30");

        conn.Open();
        SqlCommand cmd = new SqlCommand("UPDATE mps SET status = @a1 WHERE matricNo = @a2", conn);

        cmd.Parameters.AddWithValue("a1", "ACCEPTED");
        cmd.Parameters.AddWithValue("a2", matric);

        cmd.ExecuteNonQuery();
        cmd.Dispose();

        Response.Write("<script type=\"text/javascript\">alert('Validate Successful!');</script>");
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        Response.Redirect("ViewMPS_View.aspx");
    }

    protected void btnReject_Click(object sender, EventArgs e)
    {
        lblDate.Text = "-";
        lblTime.Text = "-";
        lblVenue.Text = "-";

        Response.Write("<script type=\"text/javascript\">alert('Rejection Successful!');</script>");
    }
}