﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

public partial class View_ViewMPS_View : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
        ////data soure control that works with sql database
        //SqlDataSource sds = new SqlDataSource();
        ////get connection string from application's web.config file
        //sds.ConnectionString = ConfigurationManager.ConnectionStrings["IMSConnectionString"].ToString();
        ////create parameters with specified name and values
        ////sds.SelectParameters.Add("date", TypeCode.String, date);
        ////set the sql string to retrive data from the database
        //sds.SelectCommand = "SELECT matricNo, time , venue FROM [mps] WHERE [status]='" + "ACCEPTED" + "'";
        ////retrive data
        //DataView dv = (DataView)sds.Select(DataSourceSelectArguments.Empty);
        //if (dv.Count == 0)
        //{
        //    this.Label1.Visible = true;
        //    GridView1.Visible = false;
        //    this.Label1.Text = "No Data Found";
        //    return;
        //}
        //else
        //{
        //    this.Label1.Visible = false;
        //    GridView1.DataSource = sds;
        //    GridView1.DataBind();
        //}
    }






    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        //Session["matric"] = GridView1.SelectedRow.Cells[1].Text;
        //Session["time"] = GridView1.SelectedRow.Cells[2].Text;
        //Session["venue"] = GridView1.SelectedRow.Cells[3].Text;

        //Response.Redirect("~/MPS/MPSForm_View.aspx");
    }

    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}