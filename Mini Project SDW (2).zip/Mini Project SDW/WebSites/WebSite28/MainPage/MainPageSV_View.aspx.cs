﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class MainPageSV_View : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Pavilion\Documents\IMS.mdf;Integrated Security=True;Connect Timeout=30");

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            getData(this.User.Identity.Name);
        }
        Session["nameSV"] = lblnameSV.Text;
    }

    private void getData(string user)
    {
        var username = Session["UsernameSV"] + "";
        DataTable dt = new DataTable();
        //SqlConnection connection = new SqlConnection("IMSConnectionString");
        conn.Open();
        SqlCommand sqlCmd = new SqlCommand("SELECT * from registerSV WHERE username = @username", conn);
        SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);

        sqlCmd.Parameters.AddWithValue("@username", username);
        sqlDa.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            lblnameSV.Text = dt.Rows[0]["nameSV"].ToString();
        }
        conn.Close();
    }

    protected void btnlogbook_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Manage_Logbook/LogbookMainSV.aspx");
    }

    protected void btnhome_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/MainPage/MainPageSV.aspx");
    }
}