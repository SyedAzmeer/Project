﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class MainPage_View : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Pavilion\Documents\IMS.mdf;Integrated Security=True;Connect Timeout=30");

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            getData(this.User.Identity.Name);
        }
        Session["MatricNumber"] = lblmatricNo.Text;
    }

    private void getData(string user)
    {
        var matric = Session["MatricNumber"] + "";
        DataTable dt = new DataTable();
        //SqlConnection connection = new SqlConnection("IMSConnectionString");
        conn.Open();
        SqlCommand sqlCmd = new SqlCommand("SELECT * from registerStd WHERE matricNo = @matric", conn);
        SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);

        sqlCmd.Parameters.AddWithValue("@matric", matric);
        sqlDa.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            lblname.Text = dt.Rows[0]["nameStd"].ToString();
            lblmatricNo.Text = dt.Rows[0]["matricNo"].ToString();//Where ColumnName is the Field from the DB that you want to display
        }
        conn.Close();
    }


    protected void btnhome_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/MainPage/MainPage_View.aspx");
    }

    protected void btnlogbook_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Manage_Logbook/LogbookMainStd_View.aspx");
    }
}