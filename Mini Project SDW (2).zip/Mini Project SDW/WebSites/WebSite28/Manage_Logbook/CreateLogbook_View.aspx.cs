﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class CreateLogbook_View : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Pavilion\Documents\IMS.mdf;Integrated Security=True;Connect Timeout=30");

    protected void Page_Load(object sender, EventArgs e)
    {
        txtmatricNo.Text = Session["MatricNumber"] + "";
        if (!Page.IsPostBack)
        {
            getData(this.User.Identity.Name);
        }
        

    }
     
    

    private void getData(string user)
{
    var id = Session["MatricNumber"] + "";
    DataTable dt = new DataTable();
    //SqlConnection connection = new SqlConnection("IMSConnectionString");
    conn.Open();
    SqlCommand sqlCmd = new SqlCommand("SELECT * from registerStd WHERE matricNo = @id", conn);
    SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);

    sqlCmd.Parameters.AddWithValue("@id", id);
    sqlDa.Fill(dt);
    if (dt.Rows.Count > 0)
    {
        txtnameStd.Text = dt.Rows[0]["nameStd"].ToString();
        txtmatricNo.Text = dt.Rows[0]["matricNo"].ToString();//Where ColumnName is the Field from the DB that you want to display
     }
        conn.Close();
    }


protected void btnsave_Click(object sender, EventArgs e)
    {
    
        /*Session["Day"] = Calendar1.SelectedDate.DayOfWeek;
        Session["Date"] = Calendar1.SelectedDate.ToShortDateString();
        Session["Week"] = weeklist.Text;
        Session["Title"] = txttitle.Text;
        Session["Description"] = txtdescription.Text;*/
        var day = Calendar1.SelectedDate.DayOfWeek;
        var id = txtmatricNo.Text;

        var attachment1 = attachment.FileName.ToString();
        attachment.PostedFile.SaveAs(Server.MapPath("~/upload/") + attachment1);

        conn.Open();
        SqlCommand cmd = conn.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "INSERT INTO [logbook] VALUES ('" + weeklist.SelectedItem.Text + "','" + Calendar1.SelectedDate.DayOfWeek + "','" + Calendar1.SelectedDate.ToShortDateString() + "','" + txttitle.Text + "','" + txtdescription.Text  + "','" + attachment1  + "','" + id + "')" ;
        cmd.ExecuteNonQuery();
        conn.Close();


        Response.Redirect("~/Manage_Logbook/LogbookMainStd_View.aspx");
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Manage_Logbook/LogbookMainStd.aspx");
    }

    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        
    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
}