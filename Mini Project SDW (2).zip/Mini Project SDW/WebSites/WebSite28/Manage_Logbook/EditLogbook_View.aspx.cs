﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class Manage_Logbook_EditLogbook_View : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Pavilion\Documents\IMS.mdf;Integrated Security=True;Connect Timeout=30");

    protected void Page_Load(object sender, EventArgs e)
    {
        attachment.Visible = false;
        txttitle.ReadOnly = true;
        txtdescription.ReadOnly = true;
        txtattachment.ReadOnly = true;
        if (!Page.IsPostBack)
        {
            getData(this.User.Identity.Name);
        }


    }

    private void getData(string user)
    {
        var title = Session["Title"] + "";
       
        DataTable dt = new DataTable();
        conn.Open();
        SqlCommand sqlCmd = new SqlCommand("SELECT * from logbook WHERE  [title]= @title", conn);
        SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);

        sqlCmd.Parameters.AddWithValue("@title", title);
        sqlDa.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            txtweek.Text = dt.Rows[0]["week"].ToString();
            txtdate.Text = dt.Rows[0]["date"].ToString();//Where ColumnName is the Field from the DB that you want to display
            txttitle.Text = dt.Rows[0]["title"].ToString();
            txtdescription.Text = dt.Rows[0]["description"].ToString();
            txtattachment.Text = dt.Rows[0]["attach"].ToString();
        }
        conn.Close();
    }

    protected void btnedit_Click(object sender, EventArgs e)
    {
        txttitle.ReadOnly = false;
        txttitle.Text = "";
        btnedit.Visible = false;
        //txtattachment.Visible = false;
        //attachment.Visible = true;
    }

   

    protected void btnsave_Click(object sender, EventArgs e)
    {
        var title1 = Session["title"] + "";
        var title = txttitle.Text;
        var description = txtdescription.Text;
        if (txtattachment.Text == "")
        {
            
            var attach1 = attachment.FileName.ToString();
            attachment.PostedFile.SaveAs(Server.MapPath("~/upload/") + attach1);
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Pavilion\Documents\IMS.mdf;Integrated Security=True;Connect Timeout=30");

            conn.Open();
            //SqlCommand cmd = conn.CreateCommand();
            //cmd.CommandType = CommandType.Text;

            SqlCommand cmd = new SqlCommand("UPDATE logbook SET  title = @a1, description = @a2, attach = @a3 WHERE title =@a7", conn);

            cmd.Parameters.AddWithValue("a1", title);
            cmd.Parameters.AddWithValue("a2", description);
            cmd.Parameters.AddWithValue("a3", attach1);
            cmd.Parameters.AddWithValue("a7", title1);

            cmd.ExecuteNonQuery();
            Response.Redirect("~/Manage_Logbook/LogbookMainStd_View.aspx");
        }
        else
        {
            var attach = txtattachment.Text;
            SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Pavilion\Documents\IMS.mdf;Integrated Security=True;Connect Timeout=30");

            conn.Open();
            //SqlCommand cmd = conn.CreateCommand();
            //cmd.CommandType = CommandType.Text;

            SqlCommand cmd = new SqlCommand("UPDATE logbook SET  title = @a1, description = @a2, attach = @a3 WHERE title =@a7", conn);

            cmd.Parameters.AddWithValue("a1", title);
            cmd.Parameters.AddWithValue("a2", description);
            cmd.Parameters.AddWithValue("a3", attach);
            cmd.Parameters.AddWithValue("a7", title1);

            cmd.ExecuteNonQuery();
            Response.Redirect("~/Manage_Logbook/LogbookMainStd_View.aspx");
        }

        
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Manage_Logbook/ViewLogbookStd_View.aspx");
    }

    protected void btndescription_Click(object sender, EventArgs e)
    {
        txtdescription.Text = "";
        txtdescription.ReadOnly = false;
    }

    protected void btnattachment_Click(object sender, EventArgs e)
    {
        txtattachment.Text = "";
        txtattachment.Visible = false;
        attachment.Visible = true;
    }

   
}


