﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class LogbookMainSV : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Pavilion\Documents\IMS.mdf;Integrated Security=True;Connect Timeout=30");
    string strConnString = ConfigurationManager.ConnectionStrings["IMSConnectionString"].ConnectionString;
    SqlCommand com;
    protected void Page_Load(object sender, EventArgs e)
    {
        btnView.Visible = false;
    }

    protected void weeklist_SelectedIndexChanged(object sender, EventArgs e)
    {
    }

    protected void btnsearch1_Click(object sender, EventArgs e)
    {
        var nameSV = Session["nameSV"] + "";
        //data soure control that works with sql database
        SqlDataSource sds = new SqlDataSource();
        //get connection string from application's web.config file
        sds.ConnectionString = ConfigurationManager.ConnectionStrings["IMSConnectionString"].ToString();
        //create parameters with specified name and values
        sds.SelectParameters.Add("week", TypeCode.String, this.weeklist.Text);
        sds.SelectParameters.Add("nameSV", TypeCode.String, nameSV);
        //set the sql string to retrive data from the database
        sds.SelectCommand = "SELECT logbook.day,logbook.date,logbook.title FROM logbook INNER JOIN facultylist ON logbook.matricNo = facultylist.matricNo WHERE week=@week AND Supervisor=@nameSV ";

        //retrive data
        DataView dv = (DataView)sds.Select(DataSourceSelectArguments.Empty);
        if (dv.Count == 0)
        {
            this.Label1.Visible = true;
            GridView1.Visible = false;
            this.Label1.Text = "No Data Found";
            return;
        }
        else
        {

            this.Label1.Visible = false;
            GridView1.DataSource = sds;
            GridView1.DataBind();
            btnView.Visible = true;
        }

    }



    protected void btnsearch_Click(object sender, EventArgs e)
    {

        if (searchlist.SelectedValue == "MatricNo")
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["IMSConnectionString"].ConnectionString);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("Select nameStd,matricNo,company_name,company_state,periodfrom,periodto from registerStd where matricNo like'" + txtkeyword.Text + "%'", con);
            //string text = ((TextBox)sender).Text;
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                GridView1.DataSource = ds.Tables[0];
                GridView1.DataBind();
                Label1.Visible = false;
            }
            else
            {
                Label1.Visible = true;
                Label1.Text = "No Record Found";
            }
        }

        else if (searchlist.SelectedValue == "Name")
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["IMSConnectionString"].ConnectionString);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("Select nameStd,matricNo,company_name,company_state,periodfrom,periodto from registerStd where nameStd like'" + txtkeyword.Text + "%'", con);
            //string text = ((TextBox)sender).Text;
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                GridView1.DataSource = ds.Tables[0];
                GridView1.DataBind();
                Label1.Visible = false;
            }
            else
            {
                Label1.Visible = true;
                Label1.Text = "No Record Found";
            }
        }

        else if (searchlist.SelectedValue == "Company name")
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["IMSConnectionString"].ConnectionString);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("Select nameStd,matricNo,company_name,company_state,periodfrom,periodto from registerStd where company_name like'" + txtkeyword.Text + "%'", con);
            //string text = ((TextBox)sender).Text;
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                GridView1.DataSource = ds.Tables[0];
                GridView1.DataBind();
                Label1.Visible = false;
            }
            else
            {
                Label1.Visible = true;
                Label1.Text = "No Record Found";
            }
        }

        else if (searchlist.SelectedValue == "Company State")
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["IMSConnectionString"].ConnectionString);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("Select nameStd,matricNo,company_name,company_state,periodfrom,periodto from registerStd where company_state like'" + txtkeyword.Text + "%'", con);
            //string text = ((TextBox)sender).Text;
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                GridView1.DataSource = ds.Tables[0];
                GridView1.DataBind();
                Label1.Visible = false;
            }
            else
            {
                Label1.Visible = true;
                Label1.Text = "No Record Found";
            }
        }




    }

    

    



    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {
       Session["name"] = GridView2.SelectedRow.Cells[1].Text;
    }




    protected void btnview_Click(object sender, EventArgs e)
    {

       


    }

    private void con_InfoMessage(object sender, SqlInfoMessageEventArgs e)
    {
        throw new NotImplementedException();
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Manage_Logbook/ViewLogbookSV_View.aspx");
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["Date"] = GridView1.SelectedRow.Cells[2].Text;
    }

    protected void searchlist_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}