﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class LogbookMainStd_View : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Pavilion\Documents\IMS.mdf;Integrated Security=True;Connect Timeout=30");
    //string cs = "Data Source=.;Initial Catalog=Sample;Integrated Security=true;";
    //SqlConnection con;
    //SqlDataAdapter adapt;
    //DataTable dt;
    //SqlDataReader dr;

    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Visible = false;
        //lblMatricNo.Text = Session["Matric Number"] + "";
        //lblnameStd.Text = Session["Name"] +"";
       //// lblcompany_name.Text = Session["Company Name"] + "";
        //lblcompany_state.Text = Session["Company State"] + "";
        //lblperiod.Text = Session["Period"] + "";
        if (!Page.IsPostBack)
        {
            getData(this.User.Identity.Name);
        }
    }

    private void getData(string user)
    {
        var matric = Session["MatricNumber"] + "";
        DataTable dt = new DataTable();
        //SqlConnection connection = new SqlConnection("IMSConnectionString");
        conn.Open();
        SqlCommand sqlCmd = new SqlCommand("SELECT * from registerStd WHERE matricNo = @matric", conn);
        SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);

        sqlCmd.Parameters.AddWithValue("@matric", matric);
        sqlDa.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            lblnameStd.Text = dt.Rows[0]["nameStd"].ToString(); //Where ColumnName is the Field from the DB that you want to display
            lblMatricNo.Text = dt.Rows[0]["matricNo"].ToString();
            lblcompany_name.Text = dt.Rows[0]["company_name"].ToString();
            lblcompany_state.Text = dt.Rows[0]["company_state"].ToString();
            lblperiod.Text = dt.Rows[0]["periodfrom"].ToString() + "  -  " + dt.Rows[0]["periodto"].ToString();
        }
        conn.Close();
    }

    protected void NEW_Click(object sender, EventArgs e)
    {
        Session["MatricNumber"] = lblMatricNo.Text;
        Response.Redirect("~/Manage_Logbook/CreateLogbook_View.aspx");
    }

    protected void weeklist_SelectedIndexChanged(object sender, EventArgs e)
    {
        

    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        var matric = Session["MatricNumber"] + "";
        //data soure control that works with sql database
        SqlDataSource sds = new SqlDataSource();
        //get connection string from application's web.config file
        sds.ConnectionString = ConfigurationManager.ConnectionStrings["IMSConnectionString"].ToString();
        //create parameters with specified name and values
        sds.SelectParameters.Add("week", TypeCode.String, this.weeklist.Text);
        sds.SelectParameters.Add("matric", TypeCode.String, matric);
        //set the sql string to retrive data from the database
        sds.SelectCommand = "SELECT day,date,title FROM [logbook] WHERE [week]=@week AND [matricNo]=@matric";
        //retrive data
        DataView dv = (DataView)sds.Select(DataSourceSelectArguments.Empty);
        if (dv.Count == 0)
        {
            this.Label1.Visible = true;
            GridView1.Visible = false;
            this.Label1.Text = "No Data Found";
            return;
        }
        else
        {
           
            this.Label1.Visible = false;
            GridView1.Visible = true;
            GridView1.DataSource = sds;
            GridView1.DataBind();
        }



    }


    protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
    {
        Session["Date"] = GridView1.SelectedRow.Cells[2].Text;
    }

    protected void btnview_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Manage_Logbook/ViewLogbookStd_View.aspx");
    }
}
