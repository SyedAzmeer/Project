﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class ViewLogbookSV_View : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        var date = Session["Date"] + "";
        //data soure control that works with sql database
        SqlDataSource sds = new SqlDataSource();
        //get connection string from application's web.config file
        sds.ConnectionString = ConfigurationManager.ConnectionStrings["IMSConnectionString"].ToString();
        //create parameters with specified name and values
        sds.SelectParameters.Add("date", TypeCode.String, date);
        //set the sql string to retrive data from the database
        sds.SelectCommand = "SELECT title,date,description,attach FROM [logbook] WHERE [date]=@date";
        //retrive data
        DataView dv = (DataView)sds.Select(DataSourceSelectArguments.Empty);
        if (dv.Count == 0)
        {   
            GridView1.Visible = false;
            return;
        }
        else
        {
            GridView1.DataSource = sds;
            GridView1.DataBind();
        }
    }
}