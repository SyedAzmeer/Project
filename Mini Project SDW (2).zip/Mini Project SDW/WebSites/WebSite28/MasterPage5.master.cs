﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage5 : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnlogbook_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Manage_Logbook/LogbookMainSV_View.aspx");
    }

    protected void btnhome_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/MainPage/MainPageSV_View.aspx");
    }

    protected void btnevaluation_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/OE/OEMainSV_View.aspx");
    }

    protected void generallist_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (generallist.SelectedItem.Text == "ANNOUCEMENT")
        {
            Response.Redirect("~/General_Task/AnnouncementMainSV_View.aspx");
        }
        else if (generallist.SelectedItem.Text == "FAQ")
        {
            Response.Redirect("~/General_Task/FAQMainSV_View.aspx");
        }
        else if (generallist.SelectedItem.Text == "INTERNSHIP REPORT")
        {
            Response.Redirect("~/General_Task/GenerateReportMain_View.aspx");
        }
        
    }

    protected void btnlogout_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Login/Login_View.aspx");
    }

    protected void btnassignsv_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Assign/AssignSVMain_View.aspx");
    }

    protected void btnmps_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/MPS/MPSCoordinatorMain_View.aspx");
    }
}
