﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

public partial class WebSites_WebSite1_View_OEInternship_View : System.Web.UI.Page
{
    SqlCommand cmd;
    SqlConnection conn;
    SqlDataAdapter da;

    protected void Page_Load(object sender, EventArgs e)
    {
        LblMatricNo.Text = Session["matricid"] + "";
        LblName.Text = Session["name"] + "";
    }
    protected void BtnSubmit_Click(object sender, EventArgs e)
    {
        double total = 0;
        double mark;

        if (RB1.SelectedValue == "one")
        {
            total = total + 1;
        }
        if (RB1.SelectedValue == "two")
        {
            total = total + 2;
        }
        if (RB1.SelectedValue == "three")
        {
            total = total + 3;
        }
        if (RB1.SelectedValue == "four")
        {
            total = total + 4;
        }
        if (RB1.SelectedValue == "five")
        {
            total = total + 5;
        }



        if (RB2.SelectedValue == "one")
        {
            total = total + 1;
        }
        if (RB2.SelectedValue == "two")
        {
            total = total + 2;
        }
        if (RB2.SelectedValue == "three")
        {
            total = total + 3;
        }
        if (RB2.SelectedValue == "four")
        {
            total = total + 4;
        }
        if (RB2.SelectedValue == "five")
        {
            total = total + 5;
        }



        if (RB3.SelectedValue == "one")
        {
            total = total + 1;
        }
        if (RB3.SelectedValue == "two")
        {
            total = total + 2;
        }
        if (RB3.SelectedValue == "three")
        {
            total = total + 3;
        }
        if (RB3.SelectedValue == "four")
        {
            total = total + 4;
        }
        if (RB3.SelectedValue == "five")
        {
            total = total + 5;
        }

        var status1 = Session["Status1"] + "";
        if (status1 == "Faculty Supervisor")
        {
            mark = (total / 15) * 15;

            conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Pavilion\Documents\IMS.mdf;Integrated Security=True;Connect Timeout=30");
            //var markl = Session["logbookmark"] + "";
            //var commentl = Session["logbookcomment"] + "";
            var matric = LblMatricNo.Text;
            var status = Session["Status"] + "";
            //Session["logbookmark"] = markl;
            //Session["logbookcomment"] = commentl;
            //Session["interncomment"] = TBComment.Text;
            //Session["internmark"] = mark;
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT INTO [OEintern] VALUES ('" + mark + "','" + TBComment.Text + "','" + matric + "','" + status1 + "')";
            cmd.ExecuteNonQuery();
            LblStatus.Text = "Marks submission is successful!";
            conn.Close();
        }
        if (status1 == "Industrial Supervisor")
        {
            mark = (total / 15) * 30;

            conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Pavilion\Documents\IMS.mdf;Integrated Security=True;Connect Timeout=30");
            //var markl = Session["logbookmark"] + "";
            //var commentl = Session["logbookcomment"] + "";
            var matric = LblMatricNo.Text;
            var status = Session["Status"] + "";
            //Session["logbookmark"] = markl;
            //Session["logbookcomment"] = commentl;
            //Session["interncomment"] = TBComment.Text;
            //Session["internmark"] = mark;
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT INTO [OEintern] VALUES ('" + mark + "','" + TBComment.Text + "','" + matric + "','" + status1 + "')";
            cmd.ExecuteNonQuery();
            LblStatus.Text = "Marks submission is successful!";
            conn.Close();
        }

       

        /*cmd = new SqlCommand("INSERT INTO user (internmark, interncomment) VALUES(@internmark, @interncomment)", conn);
        cmd.Parameters.AddWithValue("@internmark", mark);
        cmd.Parameters.AddWithValue("@interncomment", TBComment.Text);

        cmd.ExecuteNonQuery();
        LblStatus.Text = "Marks submission is successful!";
        conn.Close();

        //send value to ViewOE
        Session["internshipMark"] = mark;
        Session["internshipComment"] = TBComment.Text;*/

        //LblStatus.Text = "Marks submission is successful!";
    }
    protected void BtnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/OE/OEMainSV_View.aspx");
    }
    protected void BtnView_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/OE/ViewOE_View.aspx");
    }
    protected void BtnNext_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/OE/OEPresentation_View.aspx");
    }
    protected void BtnReset_Click(object sender, EventArgs e)
    {
        RB1.SelectedIndex = 0;
        RB2.SelectedIndex = 0;
        RB3.SelectedIndex = 0;
        TBComment.Text = string.Empty;
    }
}