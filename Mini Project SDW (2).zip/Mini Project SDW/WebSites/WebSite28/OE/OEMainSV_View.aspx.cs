﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

public partial class WebSites_WebSite1_View_OEMainSV_View : System.Web.UI.Page
{


    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Manage_Logbook/LogbookMainSV_View.aspx");
    }
    protected void Button2_Click1(object sender, EventArgs e)
    {
        Response.Redirect("~/OE/OELogbook_View.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/OE/OEInternship_View.aspx");
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/OE/OEPresentation_View.aspx");
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        if (DDOption.SelectedValue == "Matric ID")
        {
        //data soure control that works with sql database
        SqlDataSource sds = new SqlDataSource();
        //get connection string from application's web.config file
        sds.ConnectionString = ConfigurationManager.ConnectionStrings["IMSConnectionString"].ToString();
        //create parameters with specified name and values
        sds.SelectParameters.Add("matricNo", TypeCode.String, this.TBKeyword.Text);
        //set the sql string to retrive data from the database
        sds.SelectCommand = "SELECT nameStd,matricNo,company_name,company_state FROM [registerStd] WHERE [matricNo]=@matricNo";
        //retrive data
        DataView dv = (DataView)sds.Select(DataSourceSelectArguments.Empty);
        if (dv.Count == 0)
        {
            this.Label1.Visible = true;
            GridView1.Visible = false;
            this.Label1.Text = "No Data Found";
            return;
        }
        else
        {

            this.Label1.Visible = false;
            GridView1.DataSource = sds;
            GridView1.DataBind();
        }
        }

        if (DDOption.SelectedValue == "Name")
        {
            //data soure control that works with sql database
            SqlDataSource sds = new SqlDataSource();
            //get connection string from application's web.config file
            sds.ConnectionString = ConfigurationManager.ConnectionStrings["IMSConnectionString"].ToString();
            //create parameters with specified name and values
            sds.SelectParameters.Add("nameStd", TypeCode.String, this.TBKeyword.Text);
            //set the sql string to retrive data from the database
            sds.SelectCommand = "SELECT nameStd,matricNo,company_name,company_state FROM [registerStd] WHERE [nameStd]=@nameStd";
            //retrive data
            DataView dv = (DataView)sds.Select(DataSourceSelectArguments.Empty);
            if (dv.Count == 0)
            {
                this.Label1.Visible = true;
                GridView1.Visible = false;
                this.Label1.Text = "No Data Found";
                return;
            }
            else
            {

                this.Label1.Visible = false;
                GridView1.DataSource = sds;
                GridView1.DataBind();
            }
        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["matricid"] = GridView1.SelectedRow.Cells[2].Text;
        Session["name"] = GridView1.SelectedRow.Cells[1].Text;
    }
}