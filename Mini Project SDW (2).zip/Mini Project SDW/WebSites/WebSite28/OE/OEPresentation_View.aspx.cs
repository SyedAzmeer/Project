﻿ using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

public partial class WebSites_WebSite1_View_OEPresentation_View : System.Web.UI.Page
{
    SqlCommand cmd;
    SqlConnection conn;
    SqlDataAdapter da;

    protected void Page_Load(object sender, EventArgs e)
    {
        LblMatricNo.Text = Session["matricid"] + "";
        LblName.Text = Session["name"] + "";
    }
    protected void BtnSubmit_Click(object sender, EventArgs e)
    {
        double total = 0;
        double mark;
        

        if (RB1.SelectedValue == "one")
        {
            total = total + 1;
        }
        if (RB1.SelectedValue == "two")
        {
            total = total + 2;
        }
        if (RB1.SelectedValue == "three")
        {
            total = total + 3;
        }
        if (RB1.SelectedValue == "four")
        {
            total = total + 4;
        }
        if (RB1.SelectedValue == "five")
        {
            total = total + 5;
        }



        if (RB2.SelectedValue == "one")
        {
            total = total + 1;
        }
        if (RB2.SelectedValue == "two")
        {
            total = total + 2;
        }
        if (RB2.SelectedValue == "three")
        {
            total = total + 3;
        }
        if (RB2.SelectedValue == "four")
        {
            total = total + 4;
        }
        if (RB2.SelectedValue == "five")
        {
            total = total + 5;
        }



        if (RB3.SelectedValue == "one")
        {
            total = total + 1;
        }
        if (RB3.SelectedValue == "two")
        {
            total = total + 2;
        }
        if (RB3.SelectedValue == "three")
        {
            total = total + 3;
        }
        if (RB3.SelectedValue == "four")
        {
            total = total + 4;
        }
        if (RB3.SelectedValue == "five")
        {
            total = total + 5;
        }



        if (RB4.SelectedValue == "one")
        {
            total = total + 1;
        }
        if (RB4.SelectedValue == "two")
        {
            total = total + 2;
        }
        if (RB4.SelectedValue == "three")
        {
            total = total + 3;
        }
        if (RB4.SelectedValue == "four")
        {
            total = total + 4;
        }
        if (RB4.SelectedValue == "five")
        {
            total = total + 5;
        }

        mark = (total / 20) * 30;

        //connect database
        //var markl = Session["logbookmark"] + "";
        ////var commentl = Session["logbookcomment"] + "";
        var matric = LblMatricNo.Text;
        var status = Session["Status1"] + "";
        //var marki = Session["internmark"] + "";
        //var commenti = Session["internmark"] + "";
        //Session["logbookmark"] = markl;
        ////Session["internmark"] = commentl;
        //Session["presentationmark"] = mark;
        conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Pavilion\Documents\IMS.mdf;Integrated Security=True;Connect Timeout=30"); conn.Open();
        SqlCommand cmd = conn.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "INSERT INTO [OEpresentation] VALUES ('" + mark +  "','" + matric + "','" + status + "')";
        cmd.ExecuteNonQuery();
        LblStatus.Text = "Marks submission is successful!";
        conn.Close();

        /*cmd = new SqlCommand("INSERT INTO user (presentationmark) VALUES(@presentationmark)", conn);
        cmd.Parameters.AddWithValue("@presentationmark", mark);

        cmd.ExecuteNonQuery();
        LblStatus.Text = "Marks submission is successful!";
        conn.Close();

        //send value to ViewOE
        Session["presentationMark"] = mark;

        LblStatus.Text = "Marks submission is successful!";*/
    }
    protected void BtnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/OE/OEMainSV_View.aspx");
    }
    protected void BtnView_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/OE/ViewOE_View.aspx");
    }
    protected void BtnNext_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/OE/ViewOE_View.aspx");
    }
    protected void BtnReset_Click(object sender, EventArgs e)
    {
        RB1.SelectedIndex = 0;
        RB2.SelectedIndex = 0;
        RB3.SelectedIndex = 0;
        RB4.SelectedIndex = 0;
    }
}