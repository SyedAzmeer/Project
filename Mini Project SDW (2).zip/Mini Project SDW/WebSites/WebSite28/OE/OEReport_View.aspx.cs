﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class WebSites_WebSite1_View_OEReport_View : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Pavilion\Documents\IMS.mdf;Integrated Security=True;Connect Timeout=30");

    protected void Page_Load(object sender, EventArgs e)
    {
       
        if (!Page.IsPostBack)
        {
            getData(this.User.Identity.Name);
            getData1(this.User.Identity.Name);
            getData2(this.User.Identity.Name);
            getData3(this.User.Identity.Name);  
        }

        
        


    }

   /* int calculate()
    {
        int total;
        int mark = Convert.ToInt16(Label2.Text);
        int mark1 = Convert.ToInt16(Label8.Text);

        total = ((mark + mark1) / 45) * 30;
        
        Label4.Text = total.ToString();
    } */

    private void getData(string user)
{
     var matric = Session["MatricNumber"] + "";
    DataTable dt = new DataTable();
    //SqlConnection connection = new SqlConnection("IMSConnectionString");
    conn.Open();
    SqlCommand sqlCmd = new SqlCommand("SELECT logbookmark from OElogbook where matricNo = @matric ", conn);
    SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);
    sqlCmd.Parameters.AddWithValue("@matric", matric);
        sqlDa.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            Label1.Text = dt.Rows[0]["logbookmark"].ToString();
        }
    conn.Close();
}


    private void getData1(string user)
    {
        var matric = Session["MatricNumber"] + "";
        DataTable dt = new DataTable();
        //SqlConnection connection = new SqlConnection("IMSConnectionString");
        conn.Open();
        SqlCommand sqlCmd = new SqlCommand("SELECT internmark from OEintern where matricNo = @matric AND status = '" + "Faculty Supervisor" + "'", conn);
        SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);

        //sqlCmd.Parameters.AddWithValue("@id", id);
        sqlCmd.Parameters.AddWithValue("@matric", matric);
        sqlDa.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            Label2.Text = dt.Rows[0]["internmark"].ToString();
        }
        conn.Close();
    }

    private void getData3(string user)
    {
        var matric = Session["MatricNumber"] + "";
        DataTable dt = new DataTable();
        //SqlConnection connection = new SqlConnection("IMSConnectionString");
        conn.Open();
        SqlCommand sqlCmd = new SqlCommand("SELECT internmark from OEintern where matricNo = @matric AND status = '" + "Industrial Supervisor" + "'", conn);
        SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);

        //sqlCmd.Parameters.AddWithValue("@id", id);
        sqlCmd.Parameters.AddWithValue("@matric", matric);
        sqlDa.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            Label8.Text = dt.Rows[0]["internmark"].ToString();
        }
        conn.Close();
    }

   




    private void getData2(string user)
    {
        var matric = Session["MatricNumber"] + "";
        DataTable dt = new DataTable();
        //SqlConnection connection = new SqlConnection("IMSConnectionString");
        conn.Open();
        SqlCommand sqlCmd = new SqlCommand("SELECT presentationmark from OEpresentation where matricNo = @matric", conn);
        SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);

        //sqlCmd.Parameters.AddWithValue("@id", id);
        sqlCmd.Parameters.AddWithValue("@matric", matric);
        sqlDa.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            Label6.Text = dt.Rows[0]["presentationmark"].ToString();
            Label7.Text = dt.Rows[0]["presentationmark"].ToString();
        }
        conn.Close();
    }

    
 protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/MainPage/MainPage_View.aspx");
    }



    protected void btncalculate_Click(object sender, EventArgs e)
    {
        int total;
        int mark2 = Int32.Parse(Label1.Text);
        int mark = Int32.Parse(Label2.Text);
        int mark1 = Int32.Parse(Label8.Text);

        total = mark + mark2 + mark1;
        Label4.Text = total.ToString();
    }
}