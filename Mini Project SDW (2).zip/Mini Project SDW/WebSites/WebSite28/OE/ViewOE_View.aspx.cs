﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

public partial class WebSites_WebSite1_View_ViewOE_View : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Pavilion\Documents\IMS.mdf;Integrated Security=True;Connect Timeout=30");

    protected void Page_Load(object sender, EventArgs e)
    {
        //LblLogbookMark.Text = Session["logbookMark"] + "";
        //LblLogbookComment.Text = Session["logbookComment"] + "";

        //LblInternMark.Text = Session["internshipMark"] + "";
        //LblInternComment.Text = Session["internshipComment"] + "";

        //LblLIPresentationMark.Text = Session["presentationMark"] + "";
        if (!Page.IsPostBack)
        {
            getData1(this.User.Identity.Name);
            getData2(this.User.Identity.Name);
            getData3(this.User.Identity.Name);
        }
    }
    
    private void getData1(string user)
{
    var status = Session["Status1"] + "";
    var matricid = Session["matricid"] + "";
    DataTable dt = new DataTable();
    //SqlConnection connection = new SqlConnection("IMSConnectionString");
    conn.Open();
    SqlCommand sqlCmd = new SqlCommand("SELECT * from OElogbook  WHERE matricNo = @matricid AND status = @status ", conn);
    SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);

    sqlCmd.Parameters.AddWithValue("@matricid", matricid);
        sqlCmd.Parameters.AddWithValue("@status", status);
        sqlDa.Fill(dt);
    if (dt.Rows.Count > 0)
    {
        LblLogbookMark.Text = dt.Rows[0]["logbookmark"].ToString(); //Where ColumnName is the Field from the DB that you want to display
        LblLogbookComment.Text = dt.Rows[0]["logbookcomment"].ToString();
    }
    conn.Close();
}
     private void getData2(string user)
{
        var status = Session["Status1"] + "";
        var matricid = Session["matricid"] + "";
    DataTable dt = new DataTable();
    //SqlConnection connection = new SqlConnection("IMSConnectionString");
    conn.Open();
    SqlCommand sqlCmd = new SqlCommand("SELECT * from OEintern  WHERE matricNo = @matricid AND status = @status ", conn);
    SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);

    sqlCmd.Parameters.AddWithValue("@matricid", matricid);
        sqlCmd.Parameters.AddWithValue("@status", status);
        sqlDa.Fill(dt);
    if (dt.Rows.Count > 0)
    {
        LblInternMark.Text = dt.Rows[0]["internmark"].ToString(); //Where ColumnName is the Field from the DB that you want to display
        LblInternComment.Text = dt.Rows[0]["interncomment"].ToString();
    }
    conn.Close();
}

    private void getData3(string user)
    {
        var status = Session["Status1"] + "";
        var matricid = Session["matricid"] + "";

        DataTable dt = new DataTable();
        //SqlConnection connection = new SqlConnection("IMSConnectionString");
        conn.Open();
        SqlCommand sqlCmd = new SqlCommand("SELECT * from OEpresentation  WHERE matricNo = @matricid AND status = @status", conn);
        SqlDataAdapter sqlDa = new SqlDataAdapter(sqlCmd);

        sqlCmd.Parameters.AddWithValue("@matricid", matricid);
        sqlCmd.Parameters.AddWithValue("@status", status);
        sqlDa.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            LblLIPresentationMark.Text = dt.Rows[0]["presentationmark"].ToString(); //Where ColumnName is the Field from the DB that you want to display
        }
        conn.Close();
    }


   
    protected void BtnSubmit_Click(object sender, EventArgs e)
    {
        Session["logbookmark"] = LblLogbookMark.Text;
        Session["internmark"] = LblInternMark.Text;
        Session["presentationmark"] = LblLIPresentationMark.Text;

        Response.Redirect("~/OE/OEMainSV_View.aspx");
    }
    protected void BtnEditLogbook_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/OE/OELogbook_View.aspx");
    }
    protected void BtnEditIntern_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/OE/OEInternship_View.aspx");
    }
    protected void BtnEditPresentation_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/OE/OEPresentation_View.aspx");
    }
}