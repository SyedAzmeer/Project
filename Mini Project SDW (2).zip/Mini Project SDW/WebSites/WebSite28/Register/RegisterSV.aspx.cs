﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class Default2 : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Pavilion\Documents\IMS.mdf;Integrated Security=True;Connect Timeout=30");
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Session["Full Name"] = TBFName.Text;
        Session["Email"] = TBEmail.Text;
        Session["Phone Number"] = TBPhoneNo.Text;
        Session["Password"] = TBPass.Text;
        Session["Re-type Password"] = TBRetype.Text;

        conn.Open();
        SqlCommand cmd = conn.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "INSERT INTO [registerSV] VALUES ('" + TBFName.Text + "','" + TBEmail.Text + "','" + TBPhoneNo.Text + "','"  + TBPass.Text + "','" + TextBox1.Text + "')";
        cmd.ExecuteNonQuery();
        conn.Close();
        Response.Redirect("~/Login/Login_View.aspx");
    }

    protected void btnstudent_Click(object sender, EventArgs e)
    {
        Response.Redirect("RegisterStd.aspx");

    }

    protected void btnsv_Click(object sender, EventArgs e)
    {
        Response.Redirect("RegisterSV.aspx");
    }
}