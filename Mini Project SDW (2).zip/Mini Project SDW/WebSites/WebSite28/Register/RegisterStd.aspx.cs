﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Pavilion\Documents\IMS.mdf;Integrated Security=True;Connect Timeout=30");

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        var status = "UNASSIGNED";
        var statusmps = "UNASSIGNED";
        conn.Open();
        SqlCommand cmd = conn.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "INSERT INTO [registerStd] VALUES ('" + TbName.Text + "','" + TbMatric.Text + "','" + dropfaculty.Text + "','" + TbEmail.Text + "','" + Tbphone.Text + "','" + TbComname.Text + "','" + TbComState.Text + "','" + Tbpass.Text + "','" + txtfrom.Text + "','" + txtto.Text + "','" + status + "','" + statusmps + "')";
        cmd.ExecuteNonQuery();
        conn.Close();

        Response.Redirect("~/Login/Login_View.aspx");
    }





    protected void btnstudent_Click(object sender, EventArgs e)
    {
        Response.Redirect("RegisterStd.aspx");
    }

    protected void btnsv_Click(object sender, EventArgs e)
    {
        Response.Redirect("RegisterSv.aspx");
    }
}