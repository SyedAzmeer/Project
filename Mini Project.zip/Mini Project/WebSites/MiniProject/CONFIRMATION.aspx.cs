﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class CONFIRMATION : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblCustomerinfo.Text = "Customers Information";
        lblcontactname.Text = "Contact Name: ";
        lblmobilephonenumber.Text = "Mobile Phone Number: ";
        lblpaymentinfo.Text = "Payment Information";
        lblcardnumber.Text = "Debit/Card Credit Number: ";
        lblcardholdername.Text = "Cardholder Name: ";
        lblexpired.Text = "Expiration Date: ";
        lblsecurity.Text = "Security Code: ";
        lblemail.Text = "Email Address: ";

        lblcontactname1.Text = Session["CONTACTNAME"].ToString();
        lblmobilephonenumber1.Text = Session["COUNTRYNUM"] + "" + Session["PHONENUMBER"] + "";
        lblcardnumber1.Text = Session["DEBITNUMBER"] + "";
        lblcardholdername1.Text = Session["CARDHOLDERNAME"].ToString();
        lblexpired1.Text = Session["MONTH"] + "/" + Session["YEAR"] + "";
        lblsecurity1.Text = Session["SECURITYCODE"] + "";
        lblemail1.Text = Session["EMAIL"] + "";
        
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        System.Threading.Thread.Sleep(5000);
        lblpending.Text = "The Payment is Pending";
    }
}