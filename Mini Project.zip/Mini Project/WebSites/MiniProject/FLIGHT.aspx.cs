﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class FLIGHT : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=travel;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        if (routelist.SelectedValue == "r")
        {
            lblreturn.Visible = true;
            txtreturn.Visible = true;
        }
        else
        {
            lblreturn.Visible = false;
            txtreturn.Visible = false;
        }
    }

    protected void calculate()
    {
        double price_flight_adult;
        double price_flight_children;
        double price_flight_infants;
        double subtotal;
        double total;

        int adult = Convert.ToInt16(adultlist.Text);
        int children = Convert.ToInt16(childrenlist.Text);
        int infants = Convert.ToInt16(infantlist.Text);

        if (routelist.SelectedValue == "o")
        {
            if (fromlist.SelectedValue == "KUL" && tolist.SelectedValue == "CDG" && seatclasslist.SelectedValue == "e")
            {
                price_flight_adult = 1756.00;
                price_flight_children = 1531.00;
                price_flight_infants = 466.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = subtotal + (subtotal * 0.06);
                Session["PAYMENT"] = total.ToString();
            }
            else if (fromlist.SelectedValue == "KUL" && tolist.SelectedValue == "CDG" && seatclasslist.SelectedValue == "b")
            {
                price_flight_adult = 6060.00;
                price_flight_children = 4595.00;
                price_flight_infants = 605.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = subtotal + (subtotal * 0.06);
                Session["PAYMENT"] = total.ToString();
            }
            else if (fromlist.SelectedValue == "KUL" && tolist.SelectedValue == "CDG" && seatclasslist.SelectedValue == "fc")
            {
                price_flight_adult = 11145.00;
                price_flight_children = 8370.00;
                price_flight_infants = 2782.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = subtotal + (subtotal * 0.06);
                Session["PAYMENT"] = total.ToString();
            }
            else if (fromlist.SelectedValue == "CDG" && tolist.SelectedValue == "KUL" && seatclasslist.SelectedValue == "e")
            {
                price_flight_adult = 1887.00;
                price_flight_children = 1643.00;
                price_flight_infants = 194.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = subtotal + (subtotal * 0.06);
                Session["PAYMENT"] = total.ToString();
            }
            else if (fromlist.SelectedValue == "CDG" && tolist.SelectedValue == "KUL" && seatclasslist.SelectedValue == "b")
            {
                price_flight_adult = 7331.00;
                price_flight_children = 5763.00;
                price_flight_infants = 864.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = subtotal + (subtotal * 0.06);
                Session["PAYMENT"] = total.ToString();
            }
            else if (fromlist.SelectedValue == "CDG" && tolist.SelectedValue == "KUL" && seatclasslist.SelectedValue == "fc")
            {
                price_flight_adult = 14542.00;
                price_flight_children = 14542.00;
                price_flight_infants = 1254.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = subtotal + (subtotal * 0.06);
                Session["PAYMENT"] = total.ToString();
            }
        }
        else
        {
            if (fromlist.SelectedValue == "KUL" && tolist.SelectedValue == "CDG" && seatclasslist.SelectedValue == "e")
            {
                price_flight_adult = 1756.00;
                price_flight_children = 1531.00;
                price_flight_infants = 466.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = (subtotal + (subtotal * 0.06)) * 2;
                Session["PAYMENT"] = total.ToString();
            }
            else if (fromlist.SelectedValue == "KUL" && tolist.SelectedValue == "CDG" && seatclasslist.SelectedValue == "b")
            {
                price_flight_adult = 6060.00;
                price_flight_children = 4595.00;
                price_flight_infants = 605.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = (subtotal + (subtotal * 0.06)) * 2;
                Session["PAYMENT"] = total.ToString();
            }
            else if (fromlist.SelectedValue == "KUL" && tolist.SelectedValue == "CDG" && seatclasslist.SelectedValue == "fc")
            {
                price_flight_adult = 11145.00;
                price_flight_children = 8370.00;
                price_flight_infants = 2782.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = (subtotal + (subtotal * 0.06)) * 2;
                Session["PAYMENT"] = total.ToString();
            }
            else if (fromlist.SelectedValue == "CDG" && tolist.SelectedValue == "KUL" && seatclasslist.SelectedValue == "e")
            {
                price_flight_adult = 1887.00;
                price_flight_children = 1643.00;
                price_flight_infants = 194.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = (subtotal + (subtotal * 0.06)) * 2;
                Session["PAYMENT"] = total.ToString();
            }
            else if (fromlist.SelectedValue == "CDG" && tolist.SelectedValue == "KUL" && seatclasslist.SelectedValue == "b")
            {
                price_flight_adult = 7331.00;
                price_flight_children = 5763.00;
                price_flight_infants = 864.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = (subtotal + (subtotal * 0.06)) * 2;
                Session["PAYMENT"] = total.ToString();
            }
            else if (fromlist.SelectedValue == "CDG" && tolist.SelectedValue == "KUL" && seatclasslist.SelectedValue == "fc")
            {
                price_flight_adult = 14542.00;
                price_flight_children = 14542.00;
                price_flight_infants = 1254.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = (subtotal + (subtotal * 0.06)) * 2;
                Session["PAYMENT"] = total.ToString();
            }
        }
    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Session["FROM"] = fromlist.SelectedItem.Text;
        Session["TO"] = tolist.SelectedItem.Text;
        Session["TWOWAY"] = routelist.SelectedItem.Text;
        Session["DEPARTURE"] = txtdeparture.Text;

        if(routelist.SelectedValue == "r")
        {
            Session["RETURN"] = txtreturn.Text;
        }
        else
        {
            Session["RETURN"] = "-";
        }
        Session["ADULT"] = adultlist.SelectedItem.Text;
        Session["CHILDREN"] = childrenlist.SelectedItem.Text;
        Session["INFANTS"] = infantlist.SelectedItem.Text;
        Session["SEATCLASS"] = seatclasslist.SelectedItem.Text;

        calculate();

        conn.Open();
        SqlCommand cmd = conn.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "INSERT INTO [_flight] VALUES ('" + fromlist.SelectedItem.Text + "','" + tolist.SelectedItem.Text + "','" + txtdeparture.Text + "','" + txtreturn.Text + "','" + adultlist.SelectedItem.Text + "','" + childrenlist.SelectedItem.Text + "','" + infantlist.SelectedItem.Text + "','" + seatclasslist.SelectedItem.Text + "')";
        cmd.ExecuteNonQuery();
        conn.Close();

        Response.Redirect("FLIGHTBOOKING.aspx");
    }

}