﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class FLIGHTBOOKING : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        lblFlightDestination.Text = "Flight Destination: ";
        lblFrom.Text = "From: ";
        lblFrom1.Text = Session["FROM"] + "";
        lblTo.Text = "To: ";
        lblTo1.Text = Session["TO"] + "";
        lblDateFlight.Text = "Date of Flight: ";
        lblType.Text = "Type: ";
        lblType1.Text = Session["TWOWAY"] + "";
        lblDeparture.Text = "Departure: ";
        lblDeparture1.Text = Session["DEPARTURE"] + "";
        lblReturn.Text = "Return: ";
        lblReturn1.Text = Session["RETURN"] + "";
        lblNoPassenger.Text = "No. of Passengers: ";
        lblAdult.Text = "Adult: ";
        lblAdult1.Text = Session["ADULT"] + "";
        lblChildren.Text = "Children: ";
        lblChildren1.Text = Session["CHILDREN"] + "";
        lblInfants.Text = "Infants: ";
        lblInfants1.Text = Session["INFANTS"] + "";
        lblSeatClass.Text = "Seat Class: ";
        lblSeatClass1.Text = Session["SEATCLASS"] + "";
        lblPayment.Text = "Payments: ";
        lblPayment1.Text = "RM" + Session["PAYMENT"] + "";

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("PAYMENT.aspx");

    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("FLIGHT.aspx");
    }

    protected void Button3_Click(object sender, EventArgs e)
    {

    }
}