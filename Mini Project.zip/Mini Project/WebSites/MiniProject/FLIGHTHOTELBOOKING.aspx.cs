﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class FLIGHTHOTELBOOKING : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Hotel
        lblHotelname.Text = "Hotel Name";
        lblHotelname1.Text = Session["Hotel"] + "";
        lblCheckin.Text = "Check-in";
        lblCheckin1.Text = Session["Calcheckin"] + "";
        lblCheckout.Text = "Check-out";
        lblCheckout1.Text = Session["Calcheckout"] + "";
        lblDuration.Text = "Duration";
        lblDuration1.Text = Session["Duration"] + "";
        lblRoom.Text = "Room Type";
        lblRoom1.Text = Session["Room"] + "";
        lblGuest.Text = "Number of guest";
        lblGuest1.Text = Session["Guest"] + "";
        lblPayment.Text = "Payment:RM";
        lblPayment1.Text = Session["PAYMENTS"] + "";
        //Flight
        lblFlightDestination.Text = "Flight Destination: ";
        lblFrom.Text = "From: ";
        lblFrom1.Text = Session["FROM"] + "";
        lblTo.Text = "To: ";
        lblTo1.Text = Session["TO"] + "";
        lblDateFlight.Text = "Date of Flight: ";
        lblType.Text = "Type: ";
        lblType1.Text = Session["TWOWAY"] + "";
        lblDeparture.Text = "Departure: ";
        lblDeparture1.Text = Session["DEPARTURE"] + "";
        lblReturn.Text = "Return: ";
        lblReturn1.Text = Session["RETURN"] + "";
        lblNoPassenger.Text = "No. of Passengers: ";
        lblAdult.Text = "Adult: ";
        lblAdult1.Text = Session["ADULT"] + "";
        lblChildren.Text = "Children: ";
        lblChildren1.Text = Session["CHILDREN"] + "";
        lblInfants.Text = "Infants: ";
        lblInfants1.Text = Session["INFANTS"] + "";
        lblSeatClass.Text = "Seat Class: ";
        lblSeatClass1.Text = Session["SEATCLASS"] + "";
        lblPayment2.Text = "Payments: RM ";
        lblPayment3.Text = Session["PAYMENT"] + "";

    }

    protected void Button1_Click1(object sender, EventArgs e)
    {
        double final;
        double priceflight = Convert.ToDouble(lblPayment1.Text);
        double pricehotel = Convert.ToDouble(lblPayment3.Text);

        final = priceflight + pricehotel;

        Label1.Text = final.ToString();
        Session["FLIGHTHOTELPAYMENT"] = Label1.Text;
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("PAYMENT.aspx");

    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("FLIGHT_HOTEL.aspx");

    }
}