﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


public partial class FLIGHT_HOTEL : System.Web.UI.Page
{

    SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=travel;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        if (routelist.SelectedValue == "r")
        {
            lblreturn.Visible = true;
            txtreturn.Visible = true;
        }
        else
        {
            lblreturn.Visible = false;
            txtreturn.Visible = false;
        }

        if (roomlist1.SelectedValue == "d")
        {
            guestDlist1.Visible = true;
            guestQlist1.Visible = false;
            guestSlist1.Visible = false;
        }
        else if (roomlist1.SelectedValue == "q")
        {
            guestQlist1.Visible = true;
            guestDlist1.Visible = false;
            guestSlist1.Visible = false;
        }
        else
        {
            guestSlist1.Visible = true;
            guestDlist1.Visible = false;
            guestQlist1.Visible = false;
        }

        int night, days;

        DateTime checkin = DateTime.Parse(calcheckin1.SelectedDate.ToShortDateString());
        DateTime checkout = DateTime.Parse(calcheckout1.SelectedDate.ToShortDateString());
        night = (int)checkout.Subtract(checkin).TotalDays;
        days = night + 1;

        txtduration1.Text = days.ToString() + " Day(s)";
    }

    protected void Calculationflight()
    {
        double price_flight_adult;
        double price_flight_children;
        double price_flight_infants;
        double subtotal;
        double total;

        int adult = Convert.ToInt16(adultlist.Text);
        int children = Convert.ToInt16(childrenlist.Text);
        int infants = Convert.ToInt16(infantlist.Text);

        if (routelist.SelectedValue == "o")
        {
            if (fromlist.SelectedValue == "KUL" && tolist.SelectedValue == "CDG" && seatclasslist.SelectedValue == "e")
            {
                price_flight_adult = 1756.00;
                price_flight_children = 1531.00;
                price_flight_infants = 466.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = subtotal + (subtotal * 0.06);
               Session["PAYMENT"] = total.ToString();
            }
            else if (fromlist.SelectedValue == "KUL" && tolist.SelectedValue == "CDG" && seatclasslist.SelectedValue == "b")
            {
                price_flight_adult = 6060.00;
                price_flight_children = 4595.00;
                price_flight_infants = 605.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = subtotal + (subtotal * 0.06);
                Session["PAYMENT"] = total.ToString();
            }
            else if (fromlist.SelectedValue == "KUL" && tolist.SelectedValue == "CDG" && seatclasslist.SelectedValue == "fc")
            {
                price_flight_adult = 11145.00;
                price_flight_children = 8370.00;
                price_flight_infants = 2782.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = subtotal + (subtotal * 0.06);
                Session["PAYMENT"] = total.ToString();
            }
            else if (fromlist.SelectedValue == "CDG" && tolist.SelectedValue == "KUL" && seatclasslist.SelectedValue == "e")
            {
                price_flight_adult = 1887.00;
                price_flight_children = 1643.00;
                price_flight_infants = 194.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = subtotal + (subtotal * 0.06);
                Session["PAYMENT"] = total.ToString();
            }
            else if (fromlist.SelectedValue == "CDG" && tolist.SelectedValue == "KUL" && seatclasslist.SelectedValue == "b")
            {
                price_flight_adult = 7331.00;
                price_flight_children = 5763.00;
                price_flight_infants = 864.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = subtotal + (subtotal * 0.06);
                Session["PAYMENT"] = total.ToString();
            }
            else if (fromlist.SelectedValue == "CDG" && tolist.SelectedValue == "KUL" && seatclasslist.SelectedValue == "fc")
            {
                price_flight_adult = 14542.00;
                price_flight_children = 14542.00;
                price_flight_infants = 1254.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = subtotal + (subtotal * 0.06);
                Session["PAYMENT"] = total.ToString();
            }

            
        }
        else
        {
            if (fromlist.SelectedValue == "KUL" && tolist.SelectedValue == "CDG" && seatclasslist.SelectedValue == "e")
            {
                price_flight_adult = 1756.00;
                price_flight_children = 1531.00;
                price_flight_infants = 466.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = (subtotal + (subtotal * 0.06)) * 2;
                Session["PAYMENT"] = total.ToString();
            }
            else if (fromlist.SelectedValue == "KUL" && tolist.SelectedValue == "CDG" && seatclasslist.SelectedValue == "b")
            {
                price_flight_adult = 6060.00;
                price_flight_children = 4595.00;
                price_flight_infants = 605.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = (subtotal + (subtotal * 0.06)) * 2;
                Session["PAYMENT"] = total.ToString();
            }
            else if (fromlist.SelectedValue == "KUL" && tolist.SelectedValue == "CDG" && seatclasslist.SelectedValue == "fc")
            {
                price_flight_adult = 11145.00;
                price_flight_children = 8370.00;
                price_flight_infants = 2782.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = (subtotal + (subtotal * 0.06)) * 2;
                Session["PAYMENT"] = total.ToString();
            }
            else if (fromlist.SelectedValue == "CDG" && tolist.SelectedValue == "KUL" && seatclasslist.SelectedValue == "e")
            {
                price_flight_adult = 1887.00;
                price_flight_children = 1643.00;
                price_flight_infants = 194.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = (subtotal + (subtotal * 0.06)) * 2;
                Session["PAYMENT"] = total.ToString();
            }
            else if (fromlist.SelectedValue == "CDG" && tolist.SelectedValue == "KUL" && seatclasslist.SelectedValue == "b")
            {
                price_flight_adult = 7331.00;
                price_flight_children = 5763.00;
                price_flight_infants = 864.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = (subtotal + (subtotal * 0.06)) * 2;
                Session["PAYMENT"] = total.ToString();
            }
            else if (fromlist.SelectedValue == "CDG" && tolist.SelectedValue == "KUL" && seatclasslist.SelectedValue == "fc")
            {
                price_flight_adult = 14542.00;
                price_flight_children = 14542.00;
                price_flight_infants = 1254.00;
                subtotal = (price_flight_adult * adult) + (price_flight_children * children) + (price_flight_infants * infants);
                total = (subtotal + (subtotal * 0.06)) * 2;
                Session["PAYMENT"] = total.ToString();
            }
            
        }
    }

    protected void Calculationhotel()
    {
        int night;
        double price;
        double total;
        double gst = 0.06;
        double grandtotal;

        int roomD = Convert.ToInt16(guestDlist1.Text);
        int roomQ = Convert.ToInt16(guestQlist1.Text);
        int roomS = Convert.ToInt16(guestSlist1.Text);

        DateTime checkin = DateTime.Parse(calcheckin1.SelectedDate.ToShortDateString());
        DateTime checkout = DateTime.Parse(calcheckout1.SelectedDate.ToShortDateString());
        night = (int)checkout.Subtract(checkin).TotalDays;

        if (hotelist1.SelectedValue == "lda")
        {
            if (roomlist1.SelectedValue == "d")
            {
                price = 702.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["PAYMENTS"] = grandtotal.ToString();
            }
            else if (roomlist1.SelectedValue == "q")
            {
                price = 1215.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["PAYMENTS"] = grandtotal.ToString();
            }
            else
            {
                price = 1400.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["PAYMENTS"] = grandtotal.ToString();
            }
           
        }
        else if (hotelist1.SelectedValue == "hda")
        {
            if (roomlist1.SelectedValue == "d")
            {
                price = 921.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["PAYMENTS"] = grandtotal.ToString();
            }
            else if (roomlist1.SelectedValue == "q")
            {
                price = 1550.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["PAYMENTS"] = grandtotal.ToString();
            }
            else
            {
                price = 1718.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["PAYMENTS"] = grandtotal.ToString();
            }
       

        }
        else if (hotelist1.SelectedValue == "lvs")
        {
            if (roomlist1.SelectedValue == "d")
            {
                price = 440.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["PAYMENTS"] = grandtotal.ToString();
            }
            else if (roomlist1.SelectedValue == "q")
            {
                price = 1350.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["PAYMENTS"] = grandtotal.ToString();
            }
            else
            {
                price = 1500.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["PAYMENTS"] = grandtotal.ToString();
            }
            
        }
        else if (hotelist1.SelectedValue == "hm")
        {
            if (roomlist1.SelectedValue == "d")
            {
                price = 702.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["PAYMENTS"] = grandtotal.ToString();
            }
            else if (roomlist1.SelectedValue == "q")
            {
                price = 1215.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["PAYMENTS"] = grandtotal.ToString();
            }
            else
            {
                price = 1400.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["PAYMENTS"] = grandtotal.ToString();
            }
            
        }
        else if (hotelist1.SelectedValue == "hdpe")
        {
            if (roomlist1.SelectedValue == "d")
            {
                price = 356.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["PAYMENTS"] = grandtotal.ToString();
            }
            else if (roomlist1.SelectedValue == "q")
            {
                price = 758.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["PAYMENTS"] = grandtotal.ToString();
            }
            else
            {
                price = 1350.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["PAYMENTS"] = grandtotal.ToString();
            }
            
        }
    }

    protected void txtduration_TextChanged(object sender, EventArgs e)
    {

    }

    protected void send1_Click(object sender, ImageClickEventArgs e)
    {
        //hotel
        Session["Hotel"] = hotelist1.SelectedItem.Text;
        Session["Calcheckin"] = calcheckin1.SelectedDate.ToShortDateString();
        Session["Calcheckout"] = calcheckout1.SelectedDate.ToShortDateString();
        Session["Duration"] = txtduration1.Text;
        Session["Room"] = roomlist1.SelectedItem.Text;
        if (roomlist1.SelectedValue == "d")
        {
            Session["Guest"] = guestDlist1.Text;
        }
        else if (roomlist1.SelectedValue == "q")
        {
            Session["Guest"] = guestQlist1.Text;
        }
        else if (roomlist1.SelectedValue == "s")
        {
            Session["Guest"] = guestSlist1.Text;
        }

        Calculationhotel();
        //flight
        Session["FROM"] = fromlist.SelectedItem.Text;
        Session["TO"] = tolist.SelectedItem.Text;
        Session["TWOWAY"] = routelist.SelectedItem.Text;
        Session["DEPARTURE"] = txtdeparture.Text;
        if (routelist.SelectedValue == "r")
        {
            Session["RETURN"] = txtreturn.Text;
        }
        else
        {
            Session["RETURN"] = "-";
        }
        Session["ADULT"] = adultlist.SelectedItem.Text;
        Session["CHILDREN"] = childrenlist.SelectedItem.Text;
        Session["INFANTS"] = infantlist.SelectedItem.Text;
        Session["SEATCLASS"] = seatclasslist.SelectedItem.Text;

        Calculationflight();

        conn.Open();
        SqlCommand cmd = conn.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "INSERT INTO [flighthotel] VALUES ('" + fromlist.SelectedItem.Text + "','" + tolist.SelectedItem.Text + "','" + txtdeparture.Text + "','" + txtreturn.Text + "','" + adultlist.SelectedItem.Text + "','" + childrenlist.SelectedItem.Text + "','" + infantlist.SelectedItem.Text + "','" + seatclasslist.SelectedItem.Text + "','" + hotelist1.SelectedItem.Text + "','" + TextBox1.Text + "','" + TextBox2.Text + "','" + roomlist1.SelectedItem.Text + "','" + txtduration1.Text + "','" + guestDlist1.SelectedItem.Text + "','" + guestQlist1.SelectedItem.Text + "','" + guestSlist1.SelectedItem.Text + "')";
        cmd.ExecuteNonQuery();
        conn.Close();

        Response.Redirect("FLIGHTHOTELBOOKING.aspx");
    }

    protected void calcheckin1_SelectionChanged(object sender, EventArgs e)
    {
        TextBox1.Text = calcheckin1.SelectedDate.ToShortDateString();
    }

    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }

    protected void calcheckout1_SelectionChanged(object sender, EventArgs e)
    {
        TextBox2.Text = calcheckout1.SelectedDate.ToShortDateString();
    }
}