﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class HOTEL : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=travel;Integrated Security=True");

    public void Calculate()
    {
        int night;
        double price;
        double total;
        double gst = 0.06;
        double grandtotal;

        int roomD = Convert.ToInt16(guestDlist.Text);
        int roomQ = Convert.ToInt16(guestQlist.Text);
        int roomS = Convert.ToInt16(guestSlist.Text);

        DateTime checkin = DateTime.Parse(calcheckin.SelectedDate.ToShortDateString());
        DateTime checkout = DateTime.Parse(calcheckout.SelectedDate.ToShortDateString());
        night = (int)checkout.Subtract(checkin).TotalDays;




        if(hotelist.SelectedValue == "lda")
        {
            if(roomlist.SelectedValue == "d")
            {
                price = 702.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["Payment"] = grandtotal.ToString();
            }
            else if(roomlist.SelectedValue == "q")
            {
                price = 1215.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["Payment"] = grandtotal.ToString();
            }
            else
            {
                price = 1400.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["Payment"] = grandtotal.ToString();
            }
        }
        else if(hotelist.SelectedValue == "hda")
        {
            if (roomlist.SelectedValue == "d")
            {
                price = 921.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["Payment"] = grandtotal.ToString();
            }
            else if (roomlist.SelectedValue == "q")
            {
                price = 1550.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["Payment"] = grandtotal.ToString();
            }
            else
            {
                price = 1718.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["Payment"] = grandtotal.ToString();
            }

        }
        else if(hotelist.SelectedValue == "lvs")
        {
            if (roomlist.SelectedValue == "d")
            {
                price = 440.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["Payment"] = grandtotal.ToString();
            }
            else if (roomlist.SelectedValue == "q")
            {
                price = 1350.00;
                total = price* night;
                grandtotal = total + (total * gst);
                Session["Payment"] = grandtotal.ToString(); 
            }
            else
            {
                price = 1500.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["Payment"] = grandtotal.ToString();
            }
        }
        else if(hotelist.SelectedValue == "hm")
        {
            if (roomlist.SelectedValue == "d")
            {
                price = 702.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["Payment"] = grandtotal.ToString();
            }
            else if (roomlist.SelectedValue == "q")
            {
                price = 1215.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["Payment"] = grandtotal.ToString();
            }
            else
            {
                price = 1400.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["Payment"] = grandtotal.ToString();
            }
        }
        else if(hotelist.SelectedValue == "hdpe")
        {
            if (roomlist.SelectedValue == "d")
            {
                price = 356.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["Payment"] = grandtotal.ToString();
            }
            else if (roomlist.SelectedValue == "q")
            {
                price = 758.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["Payment"] = grandtotal.ToString();
            }
            else
            {
                price = 1350.00;
                total = price * night;
                grandtotal = total + (total * gst);
                Session["Payment"] = grandtotal.ToString();
            }
        }


    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if(roomlist.SelectedValue == "d")
        {
            guestDlist.Visible = true;
            guestQlist.Visible = false;
            guestSlist.Visible = false;
        }
        else if(roomlist.SelectedValue == "q")
        {
            guestQlist.Visible = true;
            guestDlist.Visible = false;
            guestSlist.Visible = false;
        }
        else
        {
            guestSlist.Visible = true;
            guestDlist.Visible = false;
            guestQlist.Visible = false;
        }

        int night, days;

        DateTime checkin = DateTime.Parse(calcheckin.SelectedDate.ToShortDateString());
        DateTime checkout = DateTime.Parse(calcheckout.SelectedDate.ToShortDateString());
        night = (int)checkout.Subtract(checkin).TotalDays;
        days = night + 1;

        txtduration.Text = days.ToString() + " Day(s)";
    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Session["HotelName"] = hotelist.SelectedItem.Text;
        Session["Calcheckin"] = TextBox1.Text;
        Session["Calcheckout"] = TextBox2.Text;
        Session["Duration"] = txtduration.Text;
        Session["Room"] = roomlist.SelectedItem.Text;
        if (roomlist.SelectedValue == "d")
        {
            Session["Guest"] = guestDlist.SelectedValue;
        }
        else if (roomlist.SelectedValue == "q")
        {
            Session["Guest"] = guestQlist.SelectedValue;
        }
        else if (roomlist.SelectedValue == "s")
        {
            Session["Guest"] = guestSlist.SelectedValue;
        }

        Calculate();

        conn.Open();
        SqlCommand cmd = conn.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "INSERT INTO [hotel] VALUES ('" + hotelist.SelectedItem.Text + "','" + TextBox1.Text + "','" + TextBox2.Text + "','" + txtduration.Text + "','" + roomlist.SelectedItem.Text + "','" + guestDlist.SelectedItem.Text + "','" + guestQlist.SelectedItem.Text + "','" + guestSlist.SelectedItem.Text + "')";
        cmd.ExecuteNonQuery();
        conn.Close();

        Response.Redirect("HOTELBOOKING.aspx");
    }

    protected void txtduration_TextChanged(object sender, EventArgs e)
    {
       
    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        
    }

    protected void calcheckin_SelectionChanged(object sender, EventArgs e)
    {
        TextBox1.Text = calcheckin.SelectedDate.ToShortDateString();
    }

    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }

    protected void calcheckout_SelectionChanged(object sender, EventArgs e)
    {
        TextBox2.Text = calcheckout.SelectedDate.ToShortDateString();
    }
}