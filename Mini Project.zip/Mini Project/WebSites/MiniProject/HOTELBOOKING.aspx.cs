﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class HOTELBOOKING : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblHotelname.Text = "Hotel Name";
        lblHotelname1.Text = Session["HotelName"] + "";
        lblCheckin.Text = "Check-in";
        lblCheckin1.Text = Session["Calcheckin"] + "";
        lblCheckout.Text = "Check-out";
        lblCheckout1.Text = Session["Calcheckout"] + "";
        lblDuration.Text = "Duration";
        lblDuration1.Text = Session["Duration"] + "";
        lblRoom.Text = "Room Type";
        lblRoom1.Text = Session["Room"] + "";
        lblGuest.Text = "Number of guest";
        lblGuest1.Text = Session["Guest"] + "";
        lblPayment.Text = "Payment:";
        lblPayment1.Text = "RM " + Session["Payment"] + "";
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("PAYMENT.aspx");
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("HOTEL.aspx");

    }
}