﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LOGIN : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnlgin_Click(object sender, ImageClickEventArgs e)
    {
        Session["Username"] = txtusername.Text;
        Session["Password"] = txtpass.Text;

        Response.Redirect("HOMEAFTERLOGIN.aspx");
    }

    protected void btnregister_Click(object sender, EventArgs e)
    {
        Response.Redirect("REGISTER.aspx");
    }
}