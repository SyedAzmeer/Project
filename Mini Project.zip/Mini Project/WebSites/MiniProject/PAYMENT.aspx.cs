﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PAYMENT : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
            //int card = Convert.ToInt16(TextBox3.Text);
            

        if(txtcardnumber.Text == "4" || txtcardnumber.Text.Length == 19)
        {
            Image2.Visible = true;
            Image3.Visible = false;
            Image4.Visible = false;
        }
        else if(txtcardnumber.Text == "5" || txtcardnumber.Text.Length == 16)
        {
            Image3.Visible = true;
            Image2.Visible = false;
            Image4.Visible = false;
        }
        else if(txtcardnumber.Text == "34" || txtcardnumber.Text == "37" || txtcardnumber.Text.Length == 15)
        {
            Image4.Visible = true;
            Image2.Visible = false;
            Image3.Visible = false;
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Session["CONTACTNAME"] = txtcontactname.Text;
        Session["COUNTRYCODE"] = countrycodelist.SelectedItem.Text;
        Session["COUNTRYNUM"] = countrycodelist.SelectedValue.ToString();
        Session["PHONENUMBER"] = txtphonenumber.Text;

        Session["DEBITNUMBER"] = txtcardnumber.Text;
        Session["CARDHOLDERNAME"] = txtcarholdername.Text;
        Session["MONTH"] = txtexpired.Text;
        Session["YEAR"] = txtexpired1.Text;
        Session["SECURITYCODE"] = txtsecuritycode.Text;
        Session["EMAIL"] = txtemail.Text;
        Session["PASSWORD"] = txtpass.Text;

        Response.Redirect("CONFIRMATION.aspx");
    }
}