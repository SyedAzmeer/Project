﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class REGISTER : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=travel;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {

        if(numberlist.Text == "Please choose")
        {
            txtnumber.Text = "";
        }
        else if (numberlist.Text == "Malaysia")
        {
            txtnumber.Text = "+60";
        }
        else if (numberlist.Text == "Indonesia")
        {
            txtnumber.Text = "+16";
        }
        else if(numberlist.Text == "Thailand")
        {
            txtnumber.Text = "+70";
        }
    }

    protected void txtnumber_TextChanged(object sender, EventArgs e)
    {

    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Session["FirstName"] = txtFname.Text;
        Session["LastName"] = txtLname.Text;
        Session["Username"] = txtUsername.Text;
        Session["Email"] = txtEmail.Text;
        Session["ContactNumber"] = txtnumber.Text;
        Session["ContactNumber1"] = txtnumber1.Text;
        Session["ListNumber"] = numberlist.Text;
        Session["Password"] = txtPass.Text;
        Session["CPassword"] = txtCPass.Text;

        conn.Open();
        SqlCommand cmd = conn.CreateCommand();
        cmd.CommandType = CommandType.Text;
        cmd.CommandText = "INSERT INTO [register] VALUES ('" + txtUsername.Text + "','" + txtFname.Text + "','" + txtLname.Text + "','" + txtEmail.Text + "','" + txtnumber1.Text + "','" + txtPass.Text + "')";
        cmd.ExecuteNonQuery();
        conn.Close();

        Response.Redirect("LOGIN.aspx");
    }

    protected void numberlist_SelectedIndexChanged(object sender, EventArgs e)
    {
      
    }
}