﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SEARCH : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        lbldouble.Text = "Double Room";
        lblquad.Text = "Quad Room";
        lblSuite.Text = "Suite Room";

        if(txtsearch.Text == "Montmartre")
        {
            lblname.Text = "Hotel des Arts - Montmartre";
            hotel1.Visible = true;
            hotel2.Visible = false;
            hotel3.Visible = false;
            hotel4.Visible = false;
            hotel5.Visible = false;
            hoteldouble1.Visible = true;
            hoteldouble2.Visible = false;
            hoteldouble3.Visible = false;
            hoteldouble4.Visible = false;
            hoteldouble5.Visible = false;
            hotelquad1.Visible = true;
            hotelquad2.Visible = false;
            hotelquad3.Visible = false;
            hotelquad4.Visible = false;
            hotelquad5.Visible = false;
            hotelsuite1.Visible = true;
            hotelsuite2.Visible = false;
            hotelsuite3.Visible = false;
            hotelsuite4.Visible = false;
            hotelsuite5.Visible = false;
            lblDquantity.Text = "Number of passenger: 2";
            lblDprice.Text = "Price per night: RM921.00";
            lblQquantity.Text = "Number of passenger: 4";
            lblQprice.Text = "Price per night: RM1550.00";
            lblSquantity.Text = "Number of passenger: 7";
            lblSprice.Text = "Price per night: RM1718.00";
        }
        else if (txtsearch.Text == "Germain")
        {
            lblname.Text = "La Villa Saint-Germain";
            hotel1.Visible = false;
            hotel2.Visible = true;
            hotel3.Visible = false;
            hotel4.Visible = false;
            hotel5.Visible = false;
            hoteldouble1.Visible = false;
            hoteldouble2.Visible = true;
            hoteldouble3.Visible = false;
            hoteldouble4.Visible = false;
            hoteldouble5.Visible = false;
            hotelquad1.Visible = false;
            hotelquad2.Visible = true;
            hotelquad3.Visible = false;
            hotelquad4.Visible = false;
            hotelquad5.Visible = false;
            hotelsuite1.Visible = false;
            hotelsuite2.Visible = true;
            hotelsuite3.Visible = false;
            hotelsuite4.Visible = false;
            hotelsuite5.Visible = false;
            lblDquantity.Text = "Maximum guests 2 person(s)";
            lblDprice.Text = "Price per night: RM440.00";
            lblQquantity.Text = "Maximum guests 4 person(s)";
            lblQprice.Text = "Price per night: RM1350.00";
            lblSquantity.Text = "Maximum guests 7 person(s)";
            lblSprice.Text = "Price per night: RM1500.00";
        }
        else if (txtsearch.Text == "Alma")
        {
            lblname.Text = "Le Derby Alma";
            hotel1.Visible = false;
            hotel2.Visible = false;
            hotel3.Visible = true;
            hotel4.Visible = false;
            hotel5.Visible = false;
            hoteldouble1.Visible = false;
            hoteldouble2.Visible = false;
            hoteldouble3.Visible = true;
            hoteldouble4.Visible = false;
            hoteldouble5.Visible = false;
            hotelquad1.Visible = false;
            hotelquad2.Visible = false;
            hotelquad3.Visible = true;
            hotelquad4.Visible = false;
            hotelquad5.Visible = false;
            hotelsuite1.Visible = false;
            hotelsuite2.Visible = false;
            hotelsuite3.Visible = true;
            hotelsuite4.Visible = false;
            hotelsuite5.Visible = false;
            lblDquantity.Text = "Maximum guests 2 person(s)";
            lblDprice.Text = "Price per night: RM702.00";
            lblQquantity.Text = "Maximum guests 4 person(s)";
            lblQprice.Text = "Price per night: RM1215.00";
            lblSquantity.Text = "Maximum guests 7 person(s)";
            lblSprice.Text = "Price per night: RM1400.00";
        }
        else if (txtsearch.Text == "Astotel")
        {
            lblname.Text = "Hotel Malte - Astotel";
            hotel1.Visible = false;
            hotel2.Visible = false;
            hotel3.Visible = false;
            hotel4.Visible = true;
            hotel5.Visible = false;
            hoteldouble1.Visible = false;
            hoteldouble2.Visible = false;
            hoteldouble3.Visible = false;
            hoteldouble4.Visible = true;
            hoteldouble5.Visible = false;
            hotelquad1.Visible = false;
            hotelquad2.Visible = false;
            hotelquad3.Visible = false;
            hotelquad4.Visible = true;
            hotelquad5.Visible = false;
            hotelsuite1.Visible = false;
            hotelsuite2.Visible = false;
            hotelsuite3.Visible = false;
            hotelsuite4.Visible = true;
            hotelsuite5.Visible = false;
            lblDquantity.Text = "Maximum guests 2 person(s)";
            lblDprice.Text = "Price per night: RM702.00";
            lblQquantity.Text = "Maximum guests 4 person(s)";
            lblQprice.Text = "Price per night: RM1215.00";
            lblSquantity.Text = "Maximum guests 7 person(s)";
            lblSprice.Text = "Price per night: RM1400.00";
        }
        else if (txtsearch.Text == "Eugene")
        {
            lblname.Text = "Hotel du Prince Eugene";
            hotel1.Visible = false;
            hotel2.Visible = false;
            hotel3.Visible = false;
            hotel4.Visible = false;
            hotel5.Visible = true;
            hoteldouble1.Visible = false;
            hoteldouble2.Visible = false;
            hoteldouble3.Visible = false;
            hoteldouble4.Visible = false;
            hoteldouble5.Visible = true;
            hotelquad1.Visible = false;
            hotelquad2.Visible = false;
            hotelquad3.Visible = false;
            hotelquad4.Visible = false;
            hotelquad5.Visible = true;
            hotelsuite1.Visible = false;
            hotelsuite2.Visible = false;
            hotelsuite3.Visible = false;
            hotelsuite4.Visible = false;
            hotelsuite5.Visible = true;
            lblDquantity.Text = "Maximum guests 2 person(s)";
            lblDprice.Text = "Price per night: RM356.00";
            lblQquantity.Text = "Maximum guests 4 person(s)";
            lblQprice.Text = "Price per night: RM758.00";
            lblSquantity.Text = "Maximum guests 7 person(s)";
            lblSprice.Text = "Price per night: RM1350.00";
        }
        else
        {
            hotel1.Visible = false;
            hotel2.Visible = false;
            hotel3.Visible = false;
            hotel4.Visible = false;
            hotel5.Visible = false;
            hoteldouble1.Visible = false;
            hoteldouble2.Visible = false;
            hoteldouble3.Visible = false;
            hoteldouble4.Visible = false;
            hoteldouble5.Visible = false;
            hotelquad1.Visible = false;
            hotelquad2.Visible = false;
            hotelquad3.Visible = false;
            hotelquad4.Visible = false;
            hotelquad5.Visible = false;
            hotelsuite1.Visible = false;
            hotelsuite2.Visible = false;
            hotelsuite3.Visible = false;
            hotelsuite4.Visible = false;
            hotelsuite5.Visible = false;
            lblname.Visible = false;
            lbldouble.Visible = false;
            lblquad.Visible = false;
            lblSuite.Visible = false;
            lblDquantity.Visible = false;
            lblDprice.Visible = false;
            lblQquantity.Visible = false;
            lblQprice.Visible = false;
            lblSquantity.Visible = false;
            lblSprice.Visible = false;
        }
    }
}