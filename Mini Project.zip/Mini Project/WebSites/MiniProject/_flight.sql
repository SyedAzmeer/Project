﻿CREATE TABLE [dbo].[_flight]
(
	[from] NVARCHAR(50) NOT NULL PRIMARY KEY, 
    [to] NVARCHAR(50) NOT NULL, 
    [departure] NVARCHAR(50) NOT NULL, 
    [return] NVARCHAR(50) NULL, 
    [adult] INT NOT NULL, 
    [children] INT NULL, 
    [infant] INT NULL, 
    [seatclass] NVARCHAR(50) NOT NULL
)
