﻿CREATE TABLE [dbo].[flighthotel]
(
	[from] NVARCHAR(50) NOT NULL PRIMARY KEY, 
    [to] NVARCHAR(50) NOT NULL, 
    [departure] NVARCHAR(50) NOT NULL, 
    [return] NVARCHAR(50) NULL, 
    [adult] INT NOT NULL, 
    [children] INT NULL, 
    [infant] INT NULL, 
    [seatclass] NVARCHAR(50) NOT NULL, 
    [destination] NVARCHAR(50) NOT NULL, 
    [checkin] NVARCHAR(50) NOT NULL, 
    [checkout] NVARCHAR(50) NOT NULL, 
    [room] NVARCHAR(50) NOT NULL
)
