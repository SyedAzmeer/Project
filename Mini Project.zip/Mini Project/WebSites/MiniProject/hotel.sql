﻿CREATE TABLE [dbo].[hotel]
(
	[destination] NVARCHAR(50) NOT NULL PRIMARY KEY, 
    [checkin] NVARCHAR(50) NOT NULL, 
    [checkout] NVARCHAR(50) NOT NULL, 
    [duration] INT NOT NULL, 
    [room] NVARCHAR(50) NOT NULL, 
    [guest] INT NOT NULL
)
