﻿CREATE TABLE [dbo].[Table]
(
	[username] NVARCHAR(50) NOT NULL PRIMARY KEY, 
    [firstname] NVARCHAR(50) NOT NULL, 
    [lastname] NVARCHAR(50) NOT NULL, 
    [email] NVARCHAR(50) NOT NULL, 
    [contactnum] NVARCHAR(50) NOT NULL, 
    [password] NVARCHAR(50) NOT NULL
)
